$(document).ready(function() {
	/*$('.prettyCheckable').each(function(){
		$(this).prettyCheckable();
	});*/

    //Code to display the reset password suggestion modal pop up.
    if( typeof CusDev.config.showResetPasswordModalOnCheckout != "undefined" && CusDev.config.showResetPasswordModalOnCheckout == true) {
        $('#reset-password-suggestion').modal('show');
    }
    //Code to display the reset password suggestion page.
    if( typeof CusDev.config.showResetPasswordModal != "undefined" && CusDev.config.showResetPasswordModal == true) {
        $('#reset-password-suggestion').modal('show');
    }

	$("#forgot-password-form").submit(function(e) {
		$.ajax({
            type: "POST",
            url: $(this).attr("action"),
            data: $(this).serialize(),
            success: function (response) {
                if (response.success == true) {
                	location.reload();
                } else if (typeof response.did_you_mean != "undefined" && response.did_you_mean != "") {
                    var email = $('#reset-password-email').val();
                    $('#forgot-password').modal('hide');
                    $('#emailCorrectionSuggestionModal').modal('show');
                    $('#user-email-id').text(email);
                    $('#correct-email').val(response.did_you_mean);
                    $("#confirm-link-button").attr("data-section", 'forgot-password');
                } else {

                    if( typeof response.warning != "undefined" && response.warning == true) {
                        $("#error-message-container").text(response.message);
                        return false;
                    }

                	$("#error-message-container").text(response.message);
                }
            }
        });

		return false;
		e.preventDefault();
	});

    // Default selected value on page load.
    var oldVal = $(".customer-switch:checked").val();

    //new customer / returning customer switch
    customerSwitch();

    function customerSwitch(){
        var checkedItem =  $('.customer-switch:checked');
        $($(checkedItem).data('on')).show();
        $($(checkedItem).data('off')).hide();
        oldVal = $(".customer-switch:checked").val();
    }

    //
    $('.customer-switch').change(function(){

        if ($(this).attr("id") == 'old-customer') {
            $("title").text("Account Sign-in: EZContacts.com");
        } else {
            $("title").text("Create Account: EZContacts.com");
        }

        if ($('#sign-in-submit-btn').val() != 'Continue') {
            if (this.id == 'old-customer') {
                $('#sign-in-submit-btn').val('Sign in');
            } else {
                $('#sign-in-submit-btn').val('Sign up');
            }
        }
        customerSwitch();
        setPasswordVal();
    });

    $('.customer-switch').next("a").keydown(function(e) {
        oldVal = $(".customer-switch:checked").val();
        if ("new" == $(this).prev(".customer-switch").val() && ((39 == e.keyCode) || ($(".sign-in-first-radios").length > 0 && 37 == e.keyCode) )) {
            $("#new-customer").next("a").removeClass("checked");
            $("#old-customer").click();
            $("#old-customer").next("a").focus();
            oldVal = 'old';
        } else if ("old" == $(this).prev(".customer-switch").val() && ((37 == e.keyCode) || ($(".sign-in-first-radios").length > 0 && 39 == e.keyCode) ) ) {
            $("#old-customer").next("a").removeClass("checked");
            $("#new-customer").click();
            $("#new-customer").next("a").focus();
            oldVal = 'new';
        } else if (e.keyCode == 9) {
            if (e.shiftKey == false) {
                if (oldVal == "new") {
                    $("#"+oldVal+"-customer").next("a").addClass("checked");
                    $("#UserConfirmEmail").focus();
                } else if (oldVal == "old") {
                    $("#"+oldVal+"-customer").next("a").addClass("checked");
                    $("#new-password").focus();
                }
            } else {
                if (!$("#"+oldVal+"-customer").next("a").hasClass("checked")) {
                    $("#"+oldVal+"-customer").next("a").addClass("checked");
                }
                $("#UserEmail").focus();
            }
            e.preventDefault();
        }

    });
    $('.customer-switch').next("a").next("label").click(function() {
        $(this).prev("a").focus();
    });

    //code for the email validation.
    $(".checkout_user_login_check").focusout(function(e) {
        var emailValidationError = false;
        var checkForValidation = true;
        if ($("#old-customer").is(':checked')) {
            checkForValidation = false;
        }

        if (checkForValidation && typeof CusDev.config.emailValidationEnable != 'undefined' && CusDev.config.emailValidationEnable) {
            $jxEmailValidationUrl = CusDev.config.jxEmailValidationUrl;
            var UserEmail = $("#UserEmail").val();

            $.ajax({
                'type': 'POST',
                'url': $jxEmailValidationUrl,
                'data': {email: UserEmail, fromSection: "new account"},
                'async': false,
                'success': function(response) {

                    var showSuggestion = false;

                    if (response.success == true) {
                        emailValidationError = true;
                        if(typeof response.is_deliverable != "undefined" && response.is_deliverable == false) {

                            if (typeof response.did_you_mean != "undefined" && response.did_you_mean != "") {
                                showSuggestion = true;
                            } else {
                                // alert(response.message);

                                $("#jsShowErrorModalText").html(response.message);
                                $("#jsShowErrorModal").modal('show');

                            }

                        }
                    } else if (typeof response.did_you_mean != "undefined" && response.did_you_mean != "") {
                        showSuggestion = true;
                    }

                    if (showSuggestion) {
                        var email = $("#UserEmail").val();

                        $('#emailCorrectionSuggestionModal').modal('show');
                        $('#user-email-id').text(email);
                        $('#correct-email').val(response.did_you_mean);
                        $("#confirm-link-button").attr("data-section", 'create-account');
                    }
                }
            });
        }
    });

    $("#UserEmail").keydown(function(e) {
        if (e.keyCode == 9 && e.shiftKey == false) {
            var currentVal = $(".customer-switch:checked").val();
            //$("#" + currentVal + "-customer").click();
            $("#" + currentVal + "-customer").next("a").focus();
            $('#UserUsername').val($(this).val());
            e.preventDefault();
        }
    });
    $("#UserConfirmEmail, #new-password").keydown(function(e) {
        if (e.keyCode == 9 && e.shiftKey == true) {
            var currentVal = $(".customer-switch:checked").val();
            $("#" + currentVal + "-customer").next("a").focus();
            e.preventDefault();
        }
    });

    $("#UserEmail").blur(function(e) {
        e.preventDefault();
        setPasswordVal();
    });

    // function setPasswordVal() {
    //     var fakePassVal = $.trim($("#fakepassword").val());
    //     if (('old' == $(".customer-switch:checked").val()) && fakePassVal != '') {
    //         $("#new-password").val($("#fakepassword").val());
    //     } else {
    //         $("#new-password").val("");
    //     }
    // }

    function setPasswordVal() {
        if (('old' == $(".customer-switch:checked").val())) {
            $("#new-password").val($("#new-password").val());
        } else {
            $("#new-password").val("");
        }
    }

		$("#forgot-password-link").click(function(){
			var userEmail = $("#UserEmail").val();
			if( typeof userEmail != "undefined" && userEmail != '') {
				$("#reset-password-email").val(userEmail);
			}
		});

     $("#LoginForm").submit(function(e){
        e.preventDefault();
        validatePasswordChar();
        if(scriptValidate('LoginForm') && validatePasswordChar()){
            $(this).unbind('submit').submit();
        }

    });


    $('#new-password').change(function(){
        if($(".customer-switch:checked").val() == 'new'){
           if($('#new-password-div').hasClass('error')){
                password = $('#new-password').val();
                if(password.length < 64 && password.length >= 6){
                    $('#new-password-div').removeClass('error');
                    $("#passwordJsError").hide();
                }
           }
       }
    });


    $('#confirm-link-button').click(function(){
        var correctEmail = $('#correct-email').val();
        var dataSectionValue = $(this).attr("data-section");

        $('#emailCorrectionSuggestionModal').modal('hide');
        $(this).attr("data-section", "");

        if (dataSectionValue == 'forgot-password') {

            $('#reset-password-email').val(correctEmail);
            $('#forgot-password').modal('show');

        } else if (dataSectionValue == 'create-account') {

            $("#UserEmail").val(correctEmail);
            $("#UserEmail").focus();

        } else if (dataSectionValue == 'checkout-login') {

			$("#UserEmail").val(correctEmail);
			$("#UserEmail").focus();

		}

    });

    $('#emailCorrectionSuggestionModal').on('hidden.bs.modal', function (e) {
        setTimeout(function() {
            var dataSectionValue = $('#confirm-link-button').attr("data-section");
            if (dataSectionValue == 'forgot-password') {
                $('#forgot-password').modal('show');
            } else if (dataSectionValue == 'create-account') {
                // $("#UserEmail").focus();
            }
            $('#confirm-link-button').attr("data-section", "");
        }, 200);
    });


    function pushToListrak(email) {
        function updateListrak() {
            _ltk.SCA.Update("email", email);
        }

        if (window._ltk && _ltk.SCA) {
            // Listrak already loaded
            updateListrak();
        } else {
            // Wait until Listrak is ready
            if (document.addEventListener) {
                document.addEventListener('ltkAsyncListener', updateListrak);
            } else {
                var e = document.documentElement;
                e.ltkAsyncProperty = 0;
                e.attachEvent('onpropertychange', function (evt) {
                    if (evt.propertyName == 'ltkAsyncProperty') {
                        updateListrak();
                    }
                });
            }
        }
    }

    $("#login-with-email-link-form").submit(function(e) {
        e.preventDefault();
        $(".loader").show();

        var d = new Date();

        var year = d.getFullYear();
        var month = String(d.getMonth() + 1).padStart(2, '0');
        var day = String(d.getDate()).padStart(2, '0');

        var hours = String(d.getHours()).padStart(2, '0');
        var minutes = String(d.getMinutes()).padStart(2, '0');
        var seconds = String(d.getSeconds()).padStart(2, '0');

        var formattedDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
        $('#userLocalTime').val(formattedDateTime);

        var timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        $('#userLocalTimeZone').val(timeZone);

        $.ajax({
            type: "POST",
            url: $(this).attr("action"),
            data: $(this).serialize(),
            success: function (response) {
                if (
                    typeof response.mail_sent != "undefined" &&
                    response.mail_sent &&
                    response.success &&
                    typeof response.user_email != "undefined" &&
                    response.user_email != ''
                ) {
                    if (typeof response.user_id != "undefined" && response.user_id != null) {
                        dataLayer.push({
                            'event': 'signed in',
                            'email': response.user_email,
                            'user_id': response.user_id
                        });
                    } else {
                        dataLayer.push({
                            'event': 'signed in',
                            'email': response.user_email
                        });
                    }

                    pushToListrak(response.user_email);

                    setTimeout(function() {
                        location.reload();
                    }, 2000);
                } else {
                    location.reload();
                }
            }
        });
        return false;
    });

    if(isEmailEnable && isSmsEnable){
        // if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
        //     alert('hi');
        //     $('#modalDescription').text("Let us know your mobile number, and we'll send you link to login.");
        //     $('#contact-input').attr('type', 'number').attr('placeholder', 'Enter your mobile number').attr('name', 'data[User][mobile]');
        //    }
        $('.contactMethods').change(function() {
            var contactType = $(this).val();
            $('#contact-input').val('');
            if (contactType === 'email') {
                $('#modalDescription').text(CusDev.config.popupEmailDesc);
                $('#contact-input').attr('type', 'email').attr('placeholder', CusDev.config.popupEmailInputPlaceholder).attr('name', 'data[User][email]').attr('autocomplete','email');
            } else if (contactType === 'mobile') {
                $('#modalDescription').text(CusDev.config.popupPhoneDesc);
                $('#contact-input').attr('type', 'number').attr('placeholder', CusDev.config.popupPhoneInputPlaceholder).attr('name', 'data[User][mobile]').attr('autocomplete','tel');
            }
        });
    } else if(!isEmailEnable && isSmsEnable){
        $('#modalDescription').text(CusDev.config.popupPhoneDesc);
        $('#contact-input').attr('type', 'number').attr('placeholder', CusDev.config.popupPhoneInputPlaceholder).attr('name', 'data[User][mobile]').attr('autocomplete','tel');
    } else if(isEmailEnable && !isSmsEnable){
        $('#modalDescription').text(CusDev.config.popupEmailDesc);
        $('#contact-input').attr('type', 'email').attr('placeholder', CusDev.config.popupEmailInputPlaceholder).attr('name', 'data[User][email]').attr('autocomplete','email');
    }
});

if (typeof CusDev.config.appleLogin != "undefined" && CusDev.config.appleLogin) {
    var isCheckoutPage = window.location.pathname.includes('/checkout/sign-in');
    var usePopup = (typeof CusDev.config.appleSignInType != "undefined" && CusDev.config.appleSignInType == 'redirect') ? false : true;

    document.addEventListener('DOMContentLoaded', function () {
        AppleID.auth.init({
            clientId: CusDev.config.apple_client_id,
            scope: 'name email',
            redirectURI: CusDev.config.baseURL + 'users-social-login/apple_sign_in_callback',
            state: isCheckoutPage ? 'from_checkout' : 'from_signin',
            usePopup: usePopup
        });

        if (typeof CusDev.config.appleSignInType != "undefined" && CusDev.config.appleSignInType == 'popup') {
            document.getElementById('appleid-signin').addEventListener('click', function (e) {
                e.preventDefault();

                AppleID.auth.signIn().then(response => {
                    const id_token = response.authorization && response.authorization.id_token;
                    const state = response.authorization && response.authorization.state;

                    if (!id_token) {
                        console.error('Missing id_token from Apple response');
                        return;
                    }

                    $.ajax({
                        url: '/users-social-login/apple_sign_in_callback',
                        type: 'POST',
                        data: {
                            id_token: id_token,
                            state: state
                        },
                        success: function (data) {
                            if (data.success) {
                                window.location.href = data.return_to;
                            } else {
                                window.location.href = '/account/sign-in';
                            }
                        },
                        error: function (xhr, status, error) {
                            console.error('Apple login Ajax error:');
                        }
                    });

                }).catch(error => {
                    console.error('Apple sign-in failed:', error);
                });
            });
        }
    });
}

// Code to Create protection against js script injection.
function scriptValidate(id){
    var validForm = true;
    var i=0;
    $("form#"+id+" :input").each(function(){
        var input = $(this);
        var valueStr = input.val();

        if(valueStr.indexOf("<script>") !== -1){
            $('#field'+i).remove();
            $(this).after('<span id="field'+i+'" class="error"><br/> Please do not enter script </span>');
            validForm = false;
        }else{
            $('#field'+i).remove();

            if (valueStr.indexOf("</script>") !== -1){
                $('#field'+i).remove();
                $(this).after('<span id="field'+i+'" class="error"><br/> Please do not enter script </span>');
                validForm = false;
            }else{
                if(validForm){
                    validForm = true;
                }
                $('#field'+i).remove();
            }
        }

        i++;
    });
    return validForm;
}

function validatePasswordChar(){
   if($(".customer-switch:checked").val() == 'new'){
       password = $('#new-password').val();

       if(!CusDev.config.restrictRegularLogin && password.length > 0){

            if(password.length > 64){
                $("#passwordJsError").html('The password must have less than 64 characters.');
                $( "#new-password-div" ).addClass( "error" );
                $("#passwordJsError").show();
                $("#new-password").focus();
                return false;
           }

           if(password.length < 6){
                $("#passwordJsError").html('The password must have at least 6 characters.');
                $( "#new-password-div" ).addClass( "error" );
                $("#passwordJsError").show();
                $("#new-password").focus();
                return false;
           }

       }
   }

   return true;
}
