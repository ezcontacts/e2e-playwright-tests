$(document).ready(function() {
    const config = CusDev.config.oneTapGoogleLoginConfig;

    Object.values(config).forEach(({ GoogleOneTapSetting }) => {
        if (GoogleOneTapSetting?.is_enabled && !CusDev.config.isUserLogin) {
            showContinueWithGoogle(loadTapToLogin);
        }
    });
});

let googleInitDone = false;
function showContinueWithGoogle(cb, attempts = 50, delay = 100) {
    if (googleInitDone) return;

    if (window.google && google.accounts && google.accounts.id) {
        googleInitDone = true;
        cb();
        return;
    } else {
        if (attempts <= 1) {
            return;
        }
        setTimeout(() => showContinueWithGoogle(cb, attempts - 1, delay), delay);
    }
}

function loadTapToLogin() {
    google.accounts.id.initialize({
        client_id: CusDev.config.google_client_id,
        callback: handleGoogleOneTap
    });
    google.accounts.id.prompt();
}

function handleGoogleOneTap(response) {
    if (!response || typeof response.credential !== 'string' || response.credential.trim() === '') {
        return Swal.fire({
            icon: 'error',
            title: 'Google one tap credentials not found!'
        });
    }

    $.ajax({
        url: '/users-social-login/google_one_tap_login',
        type: 'POST',
        data: {
            credential: response.credential
        },
        success: function (data) {
            if (data.success && data.redirect != '') {
                window.location.href = data.redirect;
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: data.message
                });
            }
        },
        error: function () {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: data.message
            });
        }
    });
}
