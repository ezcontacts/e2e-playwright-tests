async function wt(o) {
  const t = await fetch(o, {
    method: "GET"
  });
  if (!t.ok)
    throw new Error(`Request returned with status ${t.status}: ${t.statusText}`);
  return t.json();
}
async function St(o, t) {
  return await fetch(o, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(t)
  });
}
async function Ct(o, t) {
  return await fetch(o, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(t)
  });
}
const bt = {
  GetAsync: wt,
  PostAsync: St,
  PutAsync: Ct
};
let vt = class {
  #t = !1;
  #e = null;
  #i = !1;
  #s = /([.]*[^.]+\.(co\.uk|com|net|biz|org|co\.nz|info|jp|edu|mx|com\.br|es|ca|pro|co|au|de|com\.au|fr|eu|com\.ar|us|cl|io|store|tv|fashion|world|coop|at|ch|myshopify\.com|it|fi|sk|cz|pl|ie|com\.mx)$)|(^localhost$)/gi;
  #o = !0;
  constructor(t) {
    this.#o = t !== void 0 ? t : this.#o;
  }
  IsValidCookieDomain() {
    if (!this.#t) {
      if (window.location.hostname.toLowerCase() === "localhost")
        this.#i = !0;
      else {
        const t = window.location.host.match(this.#s);
        t && (t[0].indexOf(".") !== 0 ? this.#e = "." + t[0] : this.#e = t[0]);
      }
      this.#t = !0;
    }
    return this.#e !== null || this.#i;
  }
  GetCookieDomain() {
    return this.IsValidCookieDomain() ? this.#e : window.location.host;
  }
  GetCookie(t) {
    if (t = t.trim(), document.cookie.length > 0) {
      const e = document.cookie.indexOf(t + "=");
      if (e !== -1) {
        const i = e + t.length + 1;
        let s = document.cookie.indexOf(";", i);
        return s === -1 && (s = document.cookie.length), decodeURIComponent(document.cookie.substring(i, s));
      }
    }
    return "";
  }
  SetCookie(t, e, i, s, n, r) {
    const a = [t.trim() + "=" + encodeURIComponent(e)];
    i && a.push("expires=" + i.toUTCString()), s && a.push("domain=" + s), n && a.push("path=" + n);
    const c = window.location.protocol === "https:";
    (this.#o && c || !this.#o && r) && a.push("secure");
    const h = a.join("; ");
    document.cookie = h;
  }
  DeleteCookie(t, e, i, s) {
    this.SetCookie(t, "deleted", new Date(1970, 1, 1, 0, 0, 0), e, i, s);
  }
  AreCookiesEnabled() {
    const t = /* @__PURE__ */ new Date();
    t.setSeconds(t.getSeconds() + 180), this.SetCookie("checkCookies", "enabled", t, void 0, "/", void 0);
    const e = this.GetCookie("checkCookies") === "enabled";
    return e && this.DeleteCookie("checkCookies", void 0, "/", void 0), e;
  }
}, kt = class {
  constructor() {
    this.#t = [], this.#e = document, this.#i = null, this.#s = [], this.#o = [], this.focusableSelector = [
      "a[href]",
      "button",
      "textarea",
      "input",
      "select",
      '[tabindex]:not([tabindex="-1"])'
    ].join(",");
  }
  #t;
  #e;
  #i;
  #s;
  #o;
  #n(t) {
    if (t.target && (t.target instanceof HTMLInputElement || t.target instanceof HTMLSelectElement || t.target instanceof HTMLTextAreaElement || t.target instanceof HTMLButtonElement || t.target instanceof HTMLElement)) {
      this.#t.push(t.target);
      return;
    }
    const e = t.target;
    if (e) {
      this.#t.push(e);
      return;
    }
  }
  Initialize(t) {
    t && (this.#e = t), this.#t = [], this.#i && this.#e.removeEventListener("focusin", this.#i), this.#i = (e) => this.#n(e), this.#e.addEventListener("focusin", this.#i), this.#e.activeElement && (this.#e.activeElement instanceof HTMLInputElement || this.#e.activeElement instanceof HTMLSelectElement || this.#e.activeElement instanceof HTMLTextAreaElement || this.#e.activeElement instanceof HTMLButtonElement || this.#e.activeElement instanceof HTMLElement) && this.#t.push(this.#e.activeElement);
  }
  #r(t) {
    for (; this.#t.length > 0; ) {
      const e = this.#t.pop();
      if (e && !t.contains(e) && !(t.shadowRoot && t.shadowRoot.contains(e))) {
        this.#t.push(e);
        return;
      }
    }
  }
  ReturnFocus(t) {
    for (t && this.#r(t); this.#t.length > 0; ) {
      const e = this.#t.pop();
      if (e && e.parentNode && (!e.checkVisibility || e.checkVisibility())) {
        e.focus();
        return;
      }
    }
    this.#e.body.focus();
  }
  CollectFocusableElements(t, e, i) {
    const s = Array.from(t.childNodes), n = t;
    n && n.shadowRoot && this.CollectFocusableElements(n.shadowRoot, e, i);
    for (const r of s)
      if (r.nodeType === Node.ELEMENT_NODE) {
        const a = r;
        a && (a.matches && a.matches(e) && i.push(a), this.CollectFocusableElements(a, e, i));
      }
    return i;
  }
  DrillFocus(t) {
    return t.activeElement ? t.activeElement.shadowRoot?.activeElement ? this.DrillFocus(t.activeElement.shadowRoot) : t.activeElement : null;
  }
  TrapFocus(t) {
    this.#s.push(t);
    const e = this.CollectFocusableElements(t, this.focusableSelector, []), i = e[0], s = e[e.length - 1], n = (r) => {
      const a = r;
      if (a.key !== "Tab")
        return;
      const c = this.DrillFocus(this.#e);
      a.key === "Tab" && (a.shiftKey ? c === i && (r.preventDefault(), s.focus()) : c === s && (r.preventDefault(), i.focus()));
    };
    this.#o.push(n), t.addEventListener("keydown", n), t.shadowRoot && t.shadowRoot.addEventListener("keydown", n);
  }
  UntrapFocus(t) {
    for (let e = 0; e < this.#s.length; e++)
      if (this.#s[e] === t) {
        this.#s[e].removeEventListener("keydown", this.#o[e]), this.#s[e].shadowRoot && this.#s[e].shadowRoot?.removeEventListener("keydown", this.#o[e]), this.#s = this.#s.splice(e, 1), this.#o = this.#o.splice(e, 1);
        return;
      }
  }
};
function Et(o) {
  return o.pageY - window.scrollY;
}
function Pt(o) {
  return o.pageX - window.scrollX;
}
function xt(o) {
  document.addEventListener("mousemove", o);
}
function Tt(o) {
  document.addEventListener("mouseout", o);
}
function It(o) {
  document.removeEventListener("mousemove", o);
}
function Dt(o) {
  document.removeEventListener("mouseout", o);
}
const Ut = {
  GetMouseEventX: Pt,
  GetMouseEventY: Et,
  AddMouseMoveListener: xt,
  AddMouseOutListener: Tt,
  RemoveMouseMoveListener: It,
  RemoveMouseOutListener: Dt
};
function Rt() {
  return navigator.userAgent;
}
const At = {
  GetUserAgent: Rt
};
function A() {
  return window.Window1sc ? window.Window1sc : window;
}
function $t() {
  return A().location.href;
}
function Ft() {
  const o = A();
  return o.innerWidth ? o.innerWidth : document.documentElement.clientWidth;
}
function Mt() {
  const o = A();
  return o.innerHeight ? o.innerHeight : document.documentElement.clientHeight;
}
function Lt() {
  return A().history.length;
}
function Bt() {
  return A().location;
}
const T = {
  GetPageUrl: $t,
  GetVisibleWidth: Ft,
  GetVisibleHeight: Mt,
  GetHistoryLength: Lt,
  GetLocation: Bt
}, it = "ltk-osc-session-depth", st = "ltk-osc-source";
function Ot(o) {
  window.localStorage.setItem(st, o ? "E" : "S");
}
function Gt() {
  return window.localStorage.getItem(st);
}
function j(o, t) {
  window.localStorage.setItem(it, o + "-" + t);
}
function ot() {
  const o = window.localStorage.getItem(it);
  if (o) {
    const t = o.split("-", 2);
    return { CurrentDepth: parseInt(t[0]) || 1, HistoryLength: parseInt(t[1]) || null };
  }
  return { CurrentDepth: 1, HistoryLength: null };
}
function Nt() {
  const o = T.GetHistoryLength(), t = ot();
  t.HistoryLength !== null && t.HistoryLength < o ? j(t.CurrentDepth + 1, o) : j(t.CurrentDepth, o);
}
function Ht() {
  return ot().CurrentDepth;
}
const N = {
  InitializeSessionDepth: Nt,
  GetSessionDepth: Ht,
  StoreIsFromListrak: Ot,
  GetIsFromListrak: Gt
}, Wt = "trk_msg", _t = "trk_channel";
function H(o) {
  return new URLSearchParams(T.GetLocation().search).get(o);
}
function Vt(o) {
  return o.test(T.GetLocation().search.toLowerCase());
}
function zt() {
  H(_t) === "sms" ? N.StoreIsFromListrak(!1) : H(Wt) !== null && N.StoreIsFromListrak(!0);
}
const Jt = {
  GetString: H,
  InitializeQueryStrings: zt,
  RegexMatchQueryString: Vt
};
function qt() {
  return Math.max(
    document.body.scrollHeight,
    document.documentElement.scrollHeight,
    document.body.offsetHeight,
    document.documentElement.offsetHeight,
    document.body.clientHeight,
    document.documentElement.clientHeight
  );
}
function Qt() {
  return document.referrer;
}
const nt = {
  GetTotalHeight: qt,
  GetReferrer: Qt
}, jt = 769, W = {
  Desktop: "Desktop",
  Mobile: "Mobile"
};
function Kt() {
  return T.GetVisibleWidth() < jt ? W.Mobile : W.Desktop;
}
function Zt() {
  return /\b(iPhone|iPod|iPad)\b/i.test(navigator.userAgent);
}
const Xt = {
  Types: W,
  GetType: Kt,
  IsIOSDevice: Zt
};
function Yt() {
  const o = nt.GetTotalHeight() - T.GetVisibleHeight();
  return window.scrollY / o;
}
function te() {
  return window.scrollY;
}
function ee(o) {
  window.addEventListener("scroll", o);
}
function ie(o) {
  window.removeEventListener("scroll", o);
}
const se = {
  GetDepthFraction: Yt,
  GetDepthPixels: te,
  AddScrollListener: ee,
  RemoveScrollListener: ie
}, x = {
  Http: bt,
  Mouse: Ut,
  QueryString: Jt,
  Window: T,
  Document: nt,
  Scroll: se,
  Device: Xt,
  Cookie: new vt(),
  Focus: new kt(),
  Session: N,
  Navigator: At
};
function oe(o, t) {
  return new Promise((e, i) => {
    const s = (t || document).createElement("img");
    s.height = 1, s.width = 1, s.src = o, s.onerror = function(n) {
      i(n);
    }, s.onload = function(n) {
      e(n);
    };
  });
}
const ne = {
  TriggerAsync: oe
};
let re = class {
  static GenerateUuid() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(t) {
      const e = Math.random() * 16 | 0;
      return (t === "x" ? e : e & 3 | 8).toString(16);
    }).toUpperCase();
  }
}, ae = class {
  #t;
  #e;
  constructor(t, e) {
    this.#t = `https://${t}/EX.ashx`, this.#e = e;
  }
  async SubmitException(t, e) {
    if (t == null) return;
    const i = new URL(this.#t);
    i.searchParams.append("ctid", this.#e), i.searchParams.append("uid", re.GenerateUuid()), i.searchParams.append("n", encodeURIComponent(t.name)), i.searchParams.append("m", encodeURIComponent(t.message)), i.searchParams.append("i", encodeURIComponent(e)), i.searchParams.append("h", encodeURIComponent(document.location.href)), await ne.TriggerAsync(i.toString(), document);
  }
}, rt;
function le(o, t) {
  rt?.SubmitException(o, t).catch(() => {
  });
}
function ce(o, t) {
  rt = new ae(o, t);
}
class ue {
  #t;
  constructor(t, e, i) {
    this.#t = t, e && (this.PopupFlow = e), this.OnsiteContent = i;
  }
  OscInit() {
    this.#t.Init();
  }
}
class he {
  constructor(t) {
    this._serviceMediator = t;
  }
  // eslint-disable-next-line @typescript-eslint/naming-convention
  submitException(t, e) {
    le(t, e);
  }
}
let de = class {
  #t;
  constructor(t) {
    this.#t = t;
  }
  get #e() {
    return `offers-${this.#t}`;
  }
  get #i() {
    const t = window.localStorage.getItem(this.#e);
    if (t === null) return [];
    const e = JSON.parse(t);
    return this.#s(e.map(({ Code: i, Expiration: s, Uid: n }) => ({
      Code: i,
      Expiration: new Date(s),
      Uid: n
    })));
  }
  get HasOffers() {
    return this.#i.length > 0;
  }
  Cache(t) {
    const e = this.#i;
    e.push(t);
    const i = e.map(({ Code: s, Expiration: n, Uid: r }) => ({
      Code: s,
      Expiration: n.toISOString(),
      Uid: r
    }));
    window.localStorage.setItem(
      this.#e,
      JSON.stringify(i)
    );
  }
  GetCachedOffers() {
    return this.#i;
  }
  Clear() {
    window.localStorage.removeItem(this.#e);
  }
  Dispense(t) {
    return this.#i.length === 0 ? null : t !== void 0 ? this.#i.find((e) => e.Uid === t) ?? null : this.#i[this.#i.length - 1];
  }
  #s(t) {
    const e = (/* @__PURE__ */ new Date()).getTime();
    return t.filter((i) => i.Expiration.getTime() > e);
  }
};
class pe {
  #t;
  #e;
  constructor(t, e, i, s, n, r) {
    this.Features = t, this.#t = i, this.#e = e, this.PopupFlow = s, this.Popup = n, this.Subscription = r;
  }
  Init() {
    this.Reload(), this.#i();
  }
  Reload() {
    this.#t.Session.InitializeSessionDepth(), this.#t.QueryString.InitializeQueryStrings(), this.Features.EnablePopupFlow && this.PopupFlow.Init();
  }
  #i() {
    const t = new de(this.#e);
    document.addEventListener("ltkCheckout", () => t.Clear()), this.Features.EnablePopupFlow && this.#t.Focus.Initialize();
  }
}
let ge = class {
  #t = "ltk-subscribed";
  #e = 120;
  #i;
  constructor(t) {
    this.#i = t;
  }
  IsSubscribedToList(t) {
    return this.#i.Cookie.GetCookie(this.#t).split(",").includes(t);
  }
  AddList(t, e) {
    const i = e ?? this.#i.Cookie.GetCookieDomain(), s = this.#i.Cookie.GetCookie(this.#t)?.split(",") ?? [];
    i && !s.includes(t) && this.#i.Cookie.SetCookie(this.#t, [...s, t].join(","), this.#s(), i, "/");
  }
  RemoveList(t, e) {
    const i = e ?? this.#i.Cookie.GetCookieDomain(), s = this.#i.Cookie.GetCookie(this.#t)?.split(",") ?? [], n = s.indexOf(t);
    i && n !== -1 && (s.splice(n, 1), s.length <= 0 ? this.DeleteCookie(i) : this.#i.Cookie.SetCookie(this.#t, s.join(","), this.#s(), i, "/"));
  }
  DeleteCookie(t) {
    const e = t ?? this.#i.Cookie.GetCookieDomain();
    e && this.#i.Cookie.DeleteCookie(this.#t, e, "/");
  }
  #s() {
    const t = /* @__PURE__ */ new Date();
    return t.setMonth((/* @__PURE__ */ new Date()).getMonth() + this.#e), t;
  }
}, me = class {
  #t = "ltk-subscribed-channel-";
  #e;
  #i = 120;
  #s;
  #o = JSON.stringify({ Email: !1, Sms: !1 });
  constructor(t, e) {
    this.#s = t, this.#e = `${this.#t}${e}`;
  }
  SetEmailSubscribedChannel(t) {
    const e = JSON.parse(this.#s.Cookie.GetCookie(this.#e) || this.#o);
    this.#n({ Email: !0, Sms: e.Sms }, t);
  }
  SetSmsSubscribedChannel(t) {
    const e = JSON.parse(this.#s.Cookie.GetCookie(this.#e) || this.#o);
    this.#n({ Email: e.Email, Sms: !0 }, t);
  }
  #n(t, e) {
    const i = e ?? this.#s.Cookie.GetCookieDomain();
    this.#s.Cookie.SetCookie(this.#e, JSON.stringify(t), this.#r(), i, "/");
  }
  #r() {
    const t = /* @__PURE__ */ new Date();
    return t.setMonth((/* @__PURE__ */ new Date()).getMonth() + this.#i), t;
  }
}, fe = class {
  #t = "ltk-subscribed-email-";
  #e;
  #i = 120;
  #s;
  constructor(t, e) {
    this.#s = t, this.#e = `${this.#t}${e}`;
  }
  SetEmail(t, e) {
    const i = e ?? this.#s.Cookie.GetCookieDomain();
    this.#s.Cookie.SetCookie(this.#e, JSON.stringify(t), this.#o(), i, "/");
  }
  #o() {
    const t = /* @__PURE__ */ new Date();
    return t.setMonth((/* @__PURE__ */ new Date()).getMonth() + this.#i), t;
  }
};
class K {
  static IsValidEmail(t) {
    const e = [
      "user@example.com",
      "email@example.com",
      "customer@example.com",
      "user@domain.com",
      "email@domain.com",
      "customer@domain.com"
    ], i = /^[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    return !e.includes(t) && i.test(t);
  }
  static IsValidSMSNumber(t) {
    return t !== null && /^1?[0-9]{10}$/.test(t.replace(/\D/g, ""));
  }
}
function ye(o, t) {
  return new Promise((e, i) => {
    const s = (t || document).createElement("img");
    s.height = 1, s.width = 1, s.src = o, s.onerror = function(n) {
      i(n);
    }, s.onload = function(n) {
      e(n);
    };
  });
}
const we = {
  TriggerAsync: ye
};
let Se = class {
  static GenerateUuid() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(t) {
      const e = Math.random() * 16 | 0;
      return (t === "x" ? e : e & 3 | 8).toString(16);
    }).toUpperCase();
  }
}, Ce = class {
  #t;
  #e;
  #i;
  #s;
  #o;
  #n;
  #r;
  #l;
  #a = "Subscription.SubscriptionSubmit";
  constructor(t, e, i, s, n, r) {
    this.#t = t.MerchantTrackingId, this.#e = t.DefaultBaseUrl, this.#i = t.SessionCookieName, this.#s = e, this.#o = i, this.#n = s, this.#r = n, this.#l = r;
  }
  async SubmitSubscribeDataAsync(t) {
    const e = this.#c(t);
    await this.TriggerSubmissionRequest(e), t.List && t.SubscribeType === "s" ? (this.#s.AddList(t.List), t.SubscribeChannel === "Email" ? (this.#o.SetEmailSubscribedChannel(), this.#n.SetEmail(t.Identifier)) : t.SubscribeChannel === "SMS" && this.#o.SetSmsSubscribedChannel()) : t.List && t.SubscribeType === "u" && this.#s.RemoveList(t.List), this.#d(t.Identifier, t.SubscribeChannel), t.ResetSubscribeState;
  }
  async TriggerSubmissionRequest(t) {
    try {
      await we.TriggerAsync(t, this.#l);
    } catch {
      this.#a;
    }
  }
  // #Reset () {
  // todo: reset subscriber state
  // }
  #c(t) {
    const e = [
      this.#u("ctid", this.#t),
      this.#u("gsid", this.#i ? this.#r.Cookie.GetCookie(this.#i) : null),
      this.#u("uid", Se.GenerateUuid()),
      this.#u("_t_0", t.SubscribeType.valueOf()),
      this.#u("e_0", t.Identifier),
      this.#u("u_0", t.UpdatedIdentifier),
      this.#u("l_0", t.List),
      this.#u("s_0", t.Settings),
      this.#u("m_0", t.ModalUID),
      ...this.#h(t.ProfileItems)
    ];
    return "//" + this.#e + "/S.ashx?" + e.filter((i) => i?.split("=")[1]?.length > 0).join("&");
  }
  #h(t) {
    const e = [];
    return t.reduce((i, s) => (s.AttributeId != null && s.AttributeValue != null && i.push(encodeURIComponent(s.AttributeId) + "_0=" + encodeURIComponent(s.AttributeValue)), i), e);
  }
  #u(t, e) {
    return e == null ? "" : t + "=" + encodeURIComponent(e);
  }
  // #FireCustomEvent (event: string, list: string, Identifier: string, profile: Array<ProfileItem>) {
  // todo: implement CustomEvent
  // }
  #d(t, e) {
    switch (e) {
      case "Email": {
        if (K.IsValidEmail(t)) {
          const i = new CustomEvent("onEmailSubscribe", {
            detail: {
              email: t
            }
          });
          this.#l.dispatchEvent(i);
        }
        break;
      }
      case "SMS": {
        if (K.IsValidSMSNumber(t)) {
          const i = new CustomEvent("onSmsSubscribe", {
            detail: {
              phone: t
            }
          });
          this.#l.dispatchEvent(i);
        }
        break;
      }
    }
  }
};
function be(o, t) {
  return new Promise((e, i) => {
    const s = (t || document).createElement("img");
    s.height = 1, s.width = 1, s.src = o, s.onerror = function(n) {
      i(n);
    }, s.onload = function(n) {
      e(n);
    };
  });
}
const ve = {
  TriggerAsync: be
};
class ke {
  static GenerateUuid() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(t) {
      const e = Math.random() * 16 | 0;
      return (t === "x" ? e : e & 3 | 8).toString(16);
    }).toUpperCase();
  }
}
let Ee = class {
  #t;
  #e;
  constructor(t, e) {
    this.#t = `https://${t}/EX.ashx`, this.#e = e;
  }
  async SubmitException(t, e) {
    if (t == null) return;
    const i = new URL(this.#t);
    i.searchParams.append("ctid", this.#e), i.searchParams.append("uid", ke.GenerateUuid()), i.searchParams.append("n", encodeURIComponent(t.name)), i.searchParams.append("m", encodeURIComponent(t.message)), i.searchParams.append("i", encodeURIComponent(e)), i.searchParams.append("h", encodeURIComponent(document.location.href)), await ve.TriggerAsync(i.toString(), document);
  }
}, at;
function D(o, t) {
  at?.SubmitException(o, t).catch(() => {
  });
}
function Pe(o, t) {
  at = new Ee(o, t);
}
let xe = class {
  constructor(t, e) {
    this.PopupElementName = "listrak-popup", window.customElements.get(this.PopupElementName) || window.customElements.define(this.PopupElementName, t), this.#t = t, this.#e = [], this.#i = e;
  }
  #t;
  #e;
  #i;
  CreatePopup(t) {
    const e = new this.#t(), i = {
      ...t,
      Doc: this.#i
    };
    return e.Configure(i), this.#e.push(e), this.#i.body.appendChild(e), e;
  }
  OpenPopup(t) {
    this.#s(t)?.Open();
  }
  ClosePopup(t) {
    this.#s(t)?.Close();
  }
  #s(t) {
    return this.#e.find((i) => i.Uuid === t) || null;
  }
};
const M = {
  OnOverlayClick: !0,
  OnEscKey: !1
};
let Te = class {
  constructor() {
    this.ZIndexCeiling = 2147483647, this.TemplateSelectors = {
      ScrollContainer: "#ltkpopup-scroll-container",
      Container: "#ltkpopup-container",
      ContainerInner: "#ltkpopup-container-inner",
      Overlay: "#ltkpopup-overlay",
      Root: "listrak-popup",
      Inner: "listrak-popup-inner",
      Slot: "listrak-popup-stage",
      CloseElems: ["#ltkmodal-close"]
    }, this.#t = new AbortController(), this.#e = M.OnEscKey, this.#i = M.OnOverlayClick, this.#s = null, this.#o = new DOMParser(), this.#n = "Popup.PopupWrapper", this.#r = "none";
  }
  #t;
  #e;
  #i;
  #s;
  #o;
  #n;
  #r;
  Configure(t, e, i) {
    this.#i = t.OnOverlayClick ?? M.OnOverlayClick, this.#e = t.OnEscKey ?? M.OnEscKey, this.#r = i, this.#s = e;
  }
  SetStyleSheet(t, e) {
    if (!this.#s) {
      const s = new Error("Document not configured in popup wrapper");
      throw D(s, this.#n), s;
    }
    const i = this.#s.defaultView;
    if (i) {
      const s = new i.CSSStyleSheet();
      s.replaceSync(this.GetStyleTemplate(e)), t ? t.adoptedStyleSheets.push(s) : (this.#s.adoptedStyleSheets || (this.#s.adoptedStyleSheets = []), this.#s.adoptedStyleSheets.push(s));
    } else {
      const s = new Error("Document view not found");
      throw D(s, this.#n), s;
    }
  }
  BindCloseEvents(t, e) {
    this.#t = new AbortController();
    const i = this.TemplateSelectors.CloseElems.join(", ");
    t.querySelectorAll(i).forEach((s) => {
      s.addEventListener("click", () => {
        e.Close(!0, "closeX"), this.#t.abort();
      }, { capture: !1, signal: this.#t.signal });
    }), this.#i && t.querySelector(this.TemplateSelectors.Overlay)?.addEventListener("click", () => {
      e.Close(!0, "overlay"), this.#t.abort();
    }, { capture: !1, signal: this.#t.signal }), this.#e;
  }
  Render(t, e, i) {
    if (typeof e == "string")
      this.InsertHtml(t, e, i);
    else {
      const { Html: s = "", Js: n = "" } = e;
      this.InsertHtml(t, s, i), this.InsertJs(t, n);
    }
    this.#s?.dispatchEvent(new CustomEvent("ltk-popup-render-complete", { bubbles: !0, composed: !0 }));
  }
  InsertHtml(t, e, i) {
    const s = t.querySelector(`slot[name="${this.TemplateSelectors.Slot}"]`), { HtmlNodes: n, ScriptNodes: r } = this.#l(e);
    s ? (n.forEach((a) => {
      s.appendChild(a), a instanceof HTMLElement && a.querySelectorAll("a").forEach((c) => c.addEventListener("click", () => {
        i.dispatchEvent(new CustomEvent("link-click", { detail: { Link: c.href } }));
      }, { capture: !1 }));
    }), r.forEach((a) => this.InsertJs(t, a.textContent ?? ""))) : D(new Error("Failed to find popup wrapper to insert content."), this.#n);
  }
  InsertJs(t, e) {
    if (!this.#s || e.length === 0) return;
    const i = t.querySelector(`slot[name="${this.TemplateSelectors.Slot}"]`), s = this.#s.createElement("script");
    s.innerHTML = e, i?.appendChild(s);
  }
  InsertCustomElement(t, e) {
    t.querySelector(`slot[name="${this.TemplateSelectors.Slot}"]`)?.appendChild(e);
  }
  get Html() {
    if (this.#s) {
      const t = this.#r !== "none" ? `class="ltk-animated ltk-${this.#r}"` : "", e = this.#s.createElement("template");
      return e.innerHTML = `
      <${this.TemplateSelectors.Inner} id='ltk-popup-inner'>
        <div id="${this.TemplateSelectors.ScrollContainer.substring(1)}">
          <div id="${this.TemplateSelectors.Container.substring(1)}" ${t} role="dialog" aria-modal="true" aria-label="Modal Dialog">
            <div id="${this.TemplateSelectors.ContainerInner.substring(1)}">
              <slot name="${this.TemplateSelectors.Slot}">
            </div>
            <button id="ltkmodal-close" name=${this.TemplateSelectors.CloseElems[0]} title="Close" aria-label="Close Button">
              <span>&#x2715;</span>
            </button>
          </div>
          <div id="${this.TemplateSelectors.Overlay.substring(1)}"></div>
        </div>
      </${this.TemplateSelectors.Inner}>
      `, e;
    } else {
      const t = new Error("Document not configured in popup wrapper");
      throw D(t, this.#n), t;
    }
  }
  #l(t) {
    const e = this.#o.parseFromString(t, "text/html"), i = [];
    return e.body.querySelectorAll("script").forEach((s) => {
      i.push(s.cloneNode(!0)), s.remove();
    }), {
      HtmlNodes: Array.from(e.body.childNodes),
      ScriptNodes: i
    };
  }
  GetStyleTemplate(t) {
    const e = this.#c(t), i = e.CloseButtonColor, s = e.CloseButtonLocation, n = e.OverlayColor, r = e.OverlayTransparency;
    return `
      ${this.TemplateSelectors.CloseElems[0]} {
        height: 50px;
        width: 50px;
        display: flex;
        z-index: var(--override-popup-z-index, ${this.ZIndexCeiling});
        position: absolute;
        color: ${i || "black"};
        background-color: transparent;
        outline: none;
        border: none;
        justify-content: center;
        align-items: center;
        font-weight: bolder;
        font-size: 16pt;
        font-family: var(--override-popup-close-btn-font, Arial, Helvetica Neue, Helvetica, sans-serif);
        cursor: pointer;
        ${this.#d(s)}
      }

      ${this.TemplateSelectors.Inner},
      ${this.TemplateSelectors.Root} {
        --overlay-color: ${n};
        --overlay-opacity: ${r};

        display: none;
      }

      ${this.TemplateSelectors.Inner}[open],
      ${this.TemplateSelectors.Root}[open] {
        display: grid;
        position: fixed;
        height: 100vh;
        height: 100dvh;
        inset: 0;
        width: 100%;
        z-index: calc(var(--override-popup-z-index, ${this.ZIndexCeiling}) - 1);
      }

      ${this.TemplateSelectors.Overlay} {
        background-color: var(--overlay-color);
        display: grid;
        height: 100vh;
        height: 100dvh;
        inset: 0;
        opacity: var(--overlay-opacity);
        position: fixed;
        width: 100%;
        z-index: calc(var(--override-popup-z-index, ${this.ZIndexCeiling}) - 65);
      }

      ${this.TemplateSelectors.Inner}[open] ${this.TemplateSelectors.ScrollContainer} {
        overflow-x: hidden;
        overflow-y: auto;
        display: grid;
        z-index: calc(var(--override-popup-z-index, ${this.ZIndexCeiling}) - 64);
      }

      ${this.TemplateSelectors.Inner}[open] ${this.TemplateSelectors.Container} {
        ${this.GetContainerStyles(t)}
      }

      ${this.TemplateSelectors.ContainerInner} {
        ${this.GetContainerInnerStyles(t)}
      }

      @media (max-width:768px) {
        ${this.TemplateSelectors.Inner}[open] ${this.TemplateSelectors.Container} {
          ${t?.Popup ? "max-width: 340px;" : ""}
          ${t?.Popup?.Shape === "circle" ? "max-height: 340px" : ""}
        }
      }

      @media (max-width:${t?.Container?.MobileBreakpoint}px) {
        ${this.TemplateSelectors.Inner}[open] ${this.TemplateSelectors.Container} {
          max-width: ${t?.Container?.MobileMaxWidth}px;
        }
      }
    `;
  }
  #a(t, e, i, s) {
    const n = ["em", "rem", "vh", "vw", "lh", "rlh", "%", "px", "cm", "mm", "Q", "in", "pc", "pt"];
    return i != null && (typeof i == "string" && n.some((r) => i.endsWith(r)) && (s = void 0), t += `    ${e}: ${i}${s ?? ""};
`), t;
  }
  #c(t) {
    const e = {};
    return t !== null && (e.OverlayColor = t.Overlay?.Color, e.OverlayTransparency = t.Overlay?.Opacity, e.PagePlacement = t.Container?.PagePlacement, e.CloseButtonColor = t.Container?.CloseButtonColor, e.CloseButtonLocation = t.Container?.CloseButtonLocation, e.Shape = t.Popup?.Shape, e.Width = t.Popup?.Width, e.BorderRadius = t.Popup?.BorderRadius, e.Height = t.Popup?.Height, e.BorderStyle = t.Popup?.BorderStyle, e.BorderColor = t.Popup?.BorderColor, e.BorderWidth = t.Container?.BorderWidth, e.BackgroundColor = t.Container?.TransparentBrackground ? "transparent" : t.Container?.BackgroundColor, e.BackgroundImage = t.Popup?.BackgroundImage, e.BackgroundImageRepeat = t.Popup?.BackgroundImageRepeat, e.BackgroundImagePosition = t.Popup?.BackgroundImagePosition, e.BackgroundImageSize = t.Popup?.BackgroundImageSize, e.ContainerWidth = t.Container?.ContainerWidth || void 0), e;
  }
  GetContainerStyles(t) {
    const e = `
        position: relative;
        z-index: var(--override-popup-z-index, ${this.ZIndexCeiling});
        display: grid;
        max-height: 100vh;
        max-height: 100dvh;`, i = this.#c(t);
    if (!t)
      return e + `
        place-self: center;
        width: 600px;`;
    let s = e + `
      box-sizing: border-box;
    `;
    return i.Shape === "circle" ? (s = this.#a(s, "border-radius", "50%"), s = this.#a(s, "height", i.Width ? i.Width : 600, "px")) : (s = this.#a(s, "border-radius", i.BorderRadius, "px"), s = this.#a(s, "height", i.Height, "px")), s = this.#a(s, "place-self", i.PagePlacement ? this.#h(i.PagePlacement) : "center"), s = this.#a(s, "width", i.Width ? this.#u(i.Width) : "600px"), s = this.#a(s, "width", i?.ContainerWidth, "px"), s = this.#a(s, "border-style", i.BorderStyle), s = this.#a(s, "border-width", i.BorderWidth, "px"), s = this.#a(s, "border-color", i.BorderColor), s = this.#a(s, "background-color", i.BackgroundColor), s = this.#a(s, "background-image", i.BackgroundImage), s = this.#a(s, "background-repeat", i.BackgroundImageRepeat), i.BackgroundImagePosition !== "" && (s = this.#a(s, "background-position", i.BackgroundImagePosition)), i.BackgroundImageSize !== "" && (s = this.#a(s, "background-size", i.BackgroundImageSize)), s;
  }
  GetContainerInnerStyles(t) {
    const e = this.#c(t);
    let i = `
        display: grid;
        width: 100%;
        height: 100%;
        overscroll-behavior: contain;
    `;
    return e.Shape === "circle" ? (i = this.#a(i, "border-radius", "50%"), i = this.#a(i, "overflow-y", "hidden")) : i = this.#a(i, "border-radius", e.BorderRadius, "px"), i = this.#a(i, "place-self", e.PagePlacement ? this.#h(e.PagePlacement) : "center"), i = this.#a(i, "border-style", e.BorderStyle), i = this.#a(i, "border-width", e.BorderWidth, "px"), i = this.#a(i, "border-color", e.BorderColor), i = this.#a(i, "background-color", e.BackgroundColor), i = this.#a(i, "background-image", e.BackgroundImage), i = this.#a(i, "background-repeat", e.BackgroundImageRepeat), e.BackgroundImagePosition !== "" && (i = this.#a(i, "background-position", e.BackgroundImagePosition)), e.BackgroundImageSize !== "" && (i = this.#a(i, "background-size", e.BackgroundImageSize)), i;
  }
  #h(t) {
    switch (t) {
      case "top-left":
        return "start start";
      case "top-center":
        return "start center";
      case "top-right":
        return "start end";
      case "left":
        return "center start";
      case "center":
        return "center center";
      case "right":
        return "center end";
      case "bottom-left":
        return "end start";
      case "bottom-center":
        return "end center";
      case "bottom-right":
        return "end end";
      default:
        return "center";
    }
  }
  #u(t) {
    return `clamp(340px, ${t}px, 100vw)`;
  }
  #d(t) {
    return t === "top-left" ? "inset: 0px auto auto 0px;" : "inset: 0px 0px auto auto;";
  }
};
class Ie extends HTMLElement {
  constructor() {
    super(), this.Uuid = null, this.#t = null, this.#e = !1, this.#i = !0, this.#o = "Popup.PopupElement", this.#n = null, this.#r = "none", this.#l = null, this.#s = new Te();
  }
  #t;
  #e;
  #i;
  #s;
  #o;
  #n;
  #r;
  #l;
  // note: these callbacks are not capitalized because they are overriding functions exposed by HTMLElement
  connectedCallback() {
    this.Init(), this.#a();
  }
  disconnectedCallback() {
    this.#c();
  }
  adoptedCallback() {
  }
  attributeChangedCallback() {
  }
  static get observedAttributes() {
    return [];
  }
  get StylesheetBaseSelector() {
    return this.#i ? ":host" : "listrak-popup";
  }
  Configure(t) {
    this.Uuid = t.Uuid, this.#t = t.Doc, this.#i = t.UseShadowDom ?? !1, this.#r = t.Animation ?? "none", this.#s.Configure(t.CloseOptions, this.#t, this.#r), this.#n = t.PopupSettings, this.#l = t.Browser ? t.Browser : null;
  }
  Init() {
    if (this.Uuid === null) {
      const t = new Error("PopupElement not configured");
      throw D(t, this.#o), t;
    }
    if (this.#i && !this.shadowRoot && this.attachShadow({ mode: "open", delegatesFocus: !0 }), this.Uuid && this.setAttribute("uuid", this.Uuid), this.setAttribute("aria-hidden", "true"), this.#r !== "none") {
      const t = "ltk-animation-sheet";
      if (this.shadowRoot && this.shadowRoot?.getElementById(t) === null || this.shadowRoot === null && this.#t.getElementById(t) === null) {
        this.style.display = "none";
        const e = document.createElement("link");
        e.id = t, e.href = "https://cdn.listrakbi.com/css/animate.min.css", e.rel = "stylesheet", e.onload = () => {
          this.style.removeProperty("display");
        }, this.shadowRoot ? this.shadowRoot.appendChild(e) : this.#t.head.appendChild(e);
      }
    }
    this.shadowRoot ? (this.#s.SetStyleSheet(null, this.#n), this.#s.SetStyleSheet(this.shadowRoot, this.#n), this.shadowRoot.appendChild(this.#s.Html.content.cloneNode(!0))) : (this.#s.SetStyleSheet(null, this.#n), this.appendChild(this.#s.Html.content.cloneNode(!0)));
  }
  Open() {
    if (this.setAttribute("open", ""), this.setAttribute("aria-hidden", "false"), this.shadowRoot) {
      const t = this.shadowRoot.getElementById("ltk-popup-inner");
      t && t.setAttribute("open", "");
    } else {
      const t = this.getElementsByTagName("listrak-popup-inner");
      t.length && t[0].setAttribute("open", "");
    }
    this.HandleShowContent(), this.#e = !0, this.Focus();
  }
  Focus() {
    const t = 'input, select, textarea, a[class*="button"], button';
    if (this.shadowRoot) {
      const i = this.#l?.Focus.CollectFocusableElements(this.shadowRoot, t, []);
      if (i && i.length > 0) {
        const s = i[0];
        s.focus();
        const n = setInterval(() => {
          s.focus(), (!this.#l || this.#l.Focus.DrillFocus(this.#t ?? this.shadowRoot ?? document) === s) && clearInterval(n);
        }, 100);
        this.#l?.Focus.TrapFocus(this);
        return;
      }
    }
    const e = this.#l?.Focus.CollectFocusableElements(this, t, []);
    e && e.length > 0 && e[0].focus(), this.#l?.Focus.TrapFocus(this);
  }
  Cancel() {
    this.#e = !1, this.removeAttribute("open"), this.setAttribute("aria-hidden", "true");
  }
  Close(t, e) {
    this.#t?.activeElement && (this.shadowRoot && this.shadowRoot.contains(this.#t?.activeElement) || this.contains(this.#t?.activeElement) || this.#t?.activeElement == this) && this.#l?.Focus.ReturnFocus(this), this.#l?.Focus.UntrapFocus(this), this.#e = !1, this.removeAttribute("open"), this.setAttribute("aria-hidden", "true"), t && this.dispatchEvent(new CustomEvent("popup-close", { detail: { Source: e } }));
  }
  Remove() {
  }
  InsertContent(t) {
    if (t) {
      const e = typeof t == "string" || !Object.prototype.hasOwnProperty.call(t, "Js") ? null : t.Js;
      let i = typeof t == "string" ? t : t.Html;
      if (this.#n && this.#n?.Popup?.Shape === "circle") {
        const n = this.#n?.Popup?.Width ?? 600, r = n / 2, a = Math.round(r * Math.sqrt(2));
        i = `<div style="padding-top: ${Math.round((n - a) / 2)}px;">${i}</div>`;
      }
      const s = {
        Html: i,
        ...e ? { Js: e } : {}
      };
      this.#s.Render(this.shadowRoot ?? this, s, this);
    }
  }
  HandleShowContent() {
    this.#s.BindCloseEvents(this.shadowRoot ?? this, this);
  }
  #a() {
    this.dispatchEvent(
      new CustomEvent(
        "listrak-popup-connected",
        {
          bubbles: !0,
          detail: {
            uuid: this.Uuid,
            isVisible: this.#e
          }
        }
      )
    );
  }
  #c() {
    this.dispatchEvent(
      new CustomEvent(
        "listrak-popup-disconnected",
        {
          bubbles: !0,
          detail: {
            uuid: this.Uuid,
            isVisible: this.#e
          }
        }
      )
    );
  }
}
class De {
  static Create(t, e) {
    return Pe(t.DefaultBaseUrl, t.MerchantTrackingId), new xe(Ie, e);
  }
}
var l = /* @__PURE__ */ ((o) => (o.Any = "any", o.InitializeFlow = "init-flow", o.SuppressFlow = "suppress-flow", o.Wait = "process-wait", o.ButtonRender = "process-button-render", o.ButtonClick = "process-button-click", o.WaitComplete = "process-wait-complete", o.PreFetch = "process-prefetch", o.ContentRender = "content-render", o.OpenContent = "open-content", o.CloseContent = "close-content", o.Exit = "process-exit", o.SkipWait = "process-skip-wait", o.FormSubmission = "process-form-submission", o.AssignCoupon = "process-assign-coupon", o.PrefetchFont = "prefetch-font", o.LinkClick = "link-click", o.UrlRedirect = "url-redirect", o.RandomSplit = "split-random", o.GoToStep = "go-to-step", o.ConditionSplit = "split-condition", o.SpinClick = "spin-click", o.SpinComplete = "spin-complete", o.ExitAll = "exit-all", o.ExitAllComplete = "exit-all-complete", o))(l || {});
function Ue(o, t) {
  return new Promise((e, i) => {
    const s = (t || document).createElement("img");
    s.height = 1, s.width = 1, s.src = o, s.onerror = function(n) {
      i(n);
    }, s.onload = function(n) {
      e(n);
    };
  });
}
const Re = {
  TriggerAsync: Ue
};
class Ae {
  static GenerateUuid() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(t) {
      const e = Math.random() * 16 | 0;
      return (t === "x" ? e : e & 3 | 8).toString(16);
    }).toUpperCase();
  }
}
class $e {
  #t;
  #e;
  constructor(t, e) {
    this.#t = `https://${t}/EX.ashx`, this.#e = e;
  }
  async SubmitException(t, e) {
    if (t == null) return;
    const i = new URL(this.#t);
    i.searchParams.append("ctid", this.#e), i.searchParams.append("uid", Ae.GenerateUuid()), i.searchParams.append("n", encodeURIComponent(t.name)), i.searchParams.append("m", encodeURIComponent(t.message)), i.searchParams.append("i", encodeURIComponent(e)), i.searchParams.append("h", encodeURIComponent(document.location.href)), await Re.TriggerAsync(i.toString(), document);
  }
}
let lt;
function u(o, t) {
  lt?.SubmitException(o, t).catch(() => {
  });
}
function Fe(o, t) {
  lt = new $e(o, t);
}
function Me(o) {
  return /^(?:\+?\d{1,3}[\s-]?)?(?:\(?\d{3}\)?[\s-]?\d{3}[\s-]?\d{4})$/.test(o);
}
function Le(o) {
  return /^[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/.test(o);
}
class m {
  #t;
  #e;
  #i = 0;
  constructor(t, e) {
    this.#t = t, this.#e = e, this.#i = this.#t.Subscribe(this.#e);
  }
  async PostMessage(t) {
    await this.#t.PostMessage(t, this.#i);
  }
  Unsubscribe() {
    this.#t.Unsubscribe(this.#i);
  }
}
class E extends Error {
  constructor(t) {
    super(t), this.name = "DataNotAvailableError", Error.captureStackTrace && Error.captureStackTrace(this, E);
  }
}
const Z = "ltk-popup-flow-caching";
class Be extends m {
  #t;
  #e;
  #i;
  #s;
  #o;
  #n;
  #r;
  #l = 2;
  #a = 3;
  #c = "PopupFlow.PopupFlowService";
  #h = 0;
  constructor(t, e, i, s, n, r, a, c) {
    super(i, {
      [l.ExitAllComplete]: async () => await this.#u()
    }), this.#r = t, this.#t = e, this.#e = r, this.#i = a, this.#s = s, this.#o = n, this.#n = c;
    const h = window.localStorage.getItem(Z);
    h && JSON.parse(h) && this.SetCaching(!0);
  }
  Init() {
    this.#h++, this.PostMessage({ Type: l.ExitAll, Payload: {} });
  }
  async #u() {
    this.#h <= 0 || (this.#h--, this.#h <= 0 && await this.EvaluateRules());
  }
  async EvaluateRules() {
    try {
      const t = await this.#t.GetDataAsync();
      if (t !== void 0 && t.length > 0) {
        try {
          await this.#n.PrefetchAsync(t);
        } catch {
        }
        const e = this.#r.QueryString.GetString("ltkwebcontent");
        if (e) {
          await this.ManualTrigger(e, !1);
          return;
        }
        const i = this.#r.QueryString.GetString("ltkwebcontenttestmode"), s = this.#d(t, i === "1");
        s !== void 0 && this.PostMessage({ Type: l.InitializeFlow, Payload: s });
        const n = this.#p(t, i === "1");
        n !== void 0 && this.PostMessage({ Type: l.InitializeFlow, Payload: n });
      }
    } catch (t) {
      t instanceof E || u(t, this.#c);
    }
  }
  #d(t, e) {
    return this.#g(t.filter((i) => i.Trigger !== this.#l && i.Trigger !== this.#a && (!i.TargetingRuleSet?.TestMode || e)));
  }
  #p(t, e) {
    return this.#g(t.filter((i) => i.Trigger === this.#a && (!i.TargetingRuleSet?.TestMode || e)));
  }
  #g(t) {
    if (!this.#s.IsDebugEnabled(l.InitializeFlow))
      return this.#o.GetWinner(t);
    const e = this.#o.DebugWinner(t);
    return console.log("Rule Evaluation:", e), e.find((i) => i.Passes)?.TargetingDefinition || void 0;
  }
  EnableDebug() {
    this.#s.EnableDebug();
  }
  SetCaching(t) {
    this.#t.SetCaching(t), this.#i.SetCaching(t), this.#e.SetCaching(t), window.localStorage.setItem(Z, JSON.stringify(t));
  }
  async ManualTrigger(t, e) {
    try {
      const i = await this.#t.GetDataAsync();
      if (i !== void 0 && i.length > 0) {
        if (e)
          try {
            await this.#n.PrefetchAsync(i);
          } catch {
          }
        const s = i.find((n) => n.Uid === t);
        if (s !== void 0) {
          const n = e ? this.#g([s]) : s;
          n !== void 0 && (this.PostMessage({ Type: l.SkipWait, Payload: n }), this.PostMessage({ Type: l.InitializeFlow, Payload: n }));
        } else
          u(new Error("Error manually triggering flow: uid " + t + " not found."), this.#c);
      } else
        u(new Error("Error manually triggering flow: targeting data not found."), this.#c);
    } catch (i) {
      i instanceof E || u(i, this.#c);
    }
  }
  NextStep(t, e) {
    this.PostMessage({ Type: l.CloseContent, Payload: e }), this.PostMessage({ Type: l.WaitComplete, Payload: { Uid: t } });
  }
  ClosePopup(t, e) {
    this.PostMessage({ Type: l.CloseContent, Payload: e }), this.PostMessage({ Type: l.Exit, Payload: { Uid: t } });
  }
}
const ct = "ltk-popup-content-";
class Oe {
  #t;
  #e = !1;
  #i = null;
  #s;
  constructor(t, e, i) {
    this.#t = t, this.#i = i, this.#s = e;
  }
  SetCaching(t) {
    this.#e = t;
  }
  async GetDataAsync(t, e) {
    const i = ct + e;
    if (this.#e) {
      const r = window.sessionStorage.getItem(i);
      if (r)
        return JSON.parse(r);
    }
    const s = `${this.#t}/pf/${t}/${e}.json`, n = await this.#s.Http.GetAsync(s);
    return window.sessionStorage.setItem(i, JSON.stringify(n)), n;
  }
  async AddFonts(t) {
    if (!this.#i)
      throw new Error("Document not configured in popup wrapper");
    const e = t.Payload?.Details?.Properties?.Fonts, i = Array.from(this.#i.head.getElementsByTagName("link"));
    e.forEach((s) => {
      if (!i.some((n) => n.href === s.Url) && s.Url !== null) {
        const n = document.createElement("link");
        n.rel = "stylesheet", n.href = s.Url, this.#i?.head.appendChild(n);
      }
    });
  }
  AddAnimationPreload() {
    const t = "ltk-animation-sheet";
    if (!this.#i)
      throw new Error("Document not configured in popup wrapper");
    if (this.#i.getElementById(t) === null) {
      const e = document.createElement("link");
      e.id = t, e.href = "https://cdn.listrakbi.com/css/animate.min.css", e.rel = "preload", e.as = "style", e.onload = () => {
        e.rel = "stylesheet";
      }, this.#i.head.appendChild(e);
    }
  }
}
const Ge = "ltk-flow-processing-";
class Ne {
  #t;
  #e = !1;
  #i;
  constructor(t, e) {
    this.#t = t, this.#i = e;
  }
  SetCaching(t) {
    this.#e = t;
  }
  async GetDataAsync(t) {
    const e = Ge + t;
    if (this.#e) {
      const n = window.sessionStorage.getItem(e);
      if (n)
        return JSON.parse(n);
    }
    const i = `${this.#t}/pf/${t}/p.json`, s = await this.#i.Http.GetAsync(i);
    return window.sessionStorage.setItem(e, JSON.stringify(s)), s;
  }
}
const X = "ltk-merchant-flow-targeting";
class He {
  #t;
  #e;
  #i = !1;
  #s;
  constructor(t, e, i) {
    this.#t = t, this.#e = e, this.#s = i;
  }
  SetCaching(t) {
    this.#i = t;
  }
  async GetDataAsync() {
    if (this.#i) {
      const i = window.sessionStorage.getItem(X);
      if (i)
        return JSON.parse(i);
    }
    const t = `${this.#t}/pf/${this.#e}/t.json`, e = await this.#s.Http.GetAsync(t);
    return window.sessionStorage.setItem(X, JSON.stringify(e)), e;
  }
}
var y = /* @__PURE__ */ ((o) => (o[o.Any = -1] = "Any", o[o.Exit = 0] = "Exit", o[o.ContentRender = 3] = "ContentRender", o[o.ButtonRender = 4] = "ButtonRender", o[o.SuppressFlow = 6] = "SuppressFlow", o[o.WaitTime = 7] = "WaitTime", o[o.WaitClick = 8] = "WaitClick", o[o.WaitScroll = 9] = "WaitScroll", o[o.WaitManual = 10] = "WaitManual", o[o.WaitExit = 11] = "WaitExit", o[o.PrefetchContent = 12] = "PrefetchContent", o[o.WaitAction = 13] = "WaitAction", o[o.Coupon = 14] = "Coupon", o[o.PrefetchFont = 15] = "PrefetchFont", o[o.RandomSplit = 16] = "RandomSplit", o[o.BranchEntry = 17] = "BranchEntry", o[o.BranchExit = 18] = "BranchExit", o[o.ConditionSplit = 19] = "ConditionSplit", o[o.SpinnerRender = 20] = "SpinnerRender", o))(y || {}), S = /* @__PURE__ */ ((o) => (o[o.Request = 0] = "Request", o[o.Wait = 1] = "Wait", o[o.Behavior = 2] = "Behavior", o[o.Render = 3] = "Render", o[o.Exit = 4] = "Exit", o[o.Suppress = 5] = "Suppress", o[o.Split = 6] = "Split", o[o.Branch = 7] = "Branch", o))(S || {});
class We extends m {
  #t;
  #e = {};
  #i = {};
  #s = {};
  #o = "PopupFlow.FlowProcessingService";
  constructor(t, e) {
    super(t, {
      [l.InitializeFlow]: async (i) => await this.#r(i),
      [l.WaitComplete]: async (i) => await this.#l(i),
      [l.SkipWait]: async (i) => await this.#c(i),
      [l.ButtonClick]: async (i) => await this.#h(i),
      [l.Exit]: async (i) => await this.#u(i),
      [l.GoToStep]: async (i) => await this.#p(i),
      [l.SpinComplete]: async (i) => await this.#p(i),
      [l.ExitAll]: async () => await this.#d()
    }), this.#t = e;
  }
  #n(t) {
    t in this.#e && delete this.#e[t], t in this.#s && delete this.#s[t];
  }
  async #r(t) {
    const e = t.Payload.Uid;
    if (!e) {
      u(new Error("An error occurred processing the flow: Message sent without uid."), this.#o);
      return;
    }
    const i = this.#e[e];
    i && i !== 0 || (this.#e[e] = 0, await this.#a(e));
  }
  async #l(t) {
    const e = t.Payload.Uid;
    if (!e) {
      u(new Error("An error occurred processing the flow: Message sent without uid."), this.#o);
      return;
    }
    await this.#a(e);
  }
  async #a(t) {
    let e = this.#i[t];
    if (!e)
      try {
        e = await this.#t.GetDataAsync(t), this.#i[t] = e;
      } catch (n) {
        u(n, this.#o);
        return;
      }
    let i = this.#e[t];
    if (!i && i !== 0)
      return;
    let s = e[i];
    for (; s; ) {
      if (s?.Details?.Group !== S.Wait || !this.#s[t]) {
        const r = this.#g(s.Details);
        s.FlowUid = t, this.PostMessage({ Type: r, Payload: s });
      }
      const n = s;
      if (s?.Details?.Next) {
        if (s?.Details?.Next === s?.Details?.Current)
          break;
        i = e.findIndex((r) => s?.Details?.Next === r.Guid), this.#e[t] = i, s = e[i];
      } else
        s = void 0;
      if (n?.Details?.Group === S.Exit) {
        this.#n(t);
        break;
      } else if (n?.Details?.Group === S.Wait) {
        if (!this.#s[t])
          break;
        this.#s[t] = !1;
      }
    }
  }
  async #c(t) {
    const e = t.Payload.Uid;
    if (!e) {
      u(new Error("An error occurred skipping wait: Message sent without uid."), this.#o);
      return;
    }
    this.#s[e] = !0;
  }
  async #h(t) {
    const e = t.Payload.Uid;
    if (!e) {
      u(new Error("An error occurred while reading button click. Cannot process flow event without uid."), this.#o);
      return;
    }
    const i = this.#e[e];
    if (i && i !== 0) {
      const s = this.#i[e];
      i > 0 && s && s[i - 1] && s[i - 1].Details?.Group === S.Wait && s[i - 1].Details?.Type === y.WaitClick && await this.#a(e);
      return;
    }
    await this.#c(t), await this.#r(t);
  }
  async #u(t) {
    const e = t.Payload.Uid;
    if (!e) {
      u(new Error("An error occurred exiting: Message sent without uid."), this.#o);
      return;
    }
    this.#n(e);
  }
  async #d() {
    for (const t in this.#e)
      try {
        this.PostMessage({ Type: l.Exit, Payload: { Uid: t } }), this.#n(t);
      } catch (e) {
        u(e, this.#o);
      }
    this.PostMessage({ Type: l.ExitAllComplete, Payload: {} });
  }
  async #p(t) {
    const e = t.Payload.Uid;
    if (!e) {
      u(new Error("An error occurred exiting: Message sent without uid."), this.#o);
      return;
    }
    const i = t.Payload.StepUid;
    if (!i) {
      u(new Error("An error occurred exiting: Message sent without step uid."), this.#o);
      return;
    }
    this.#e[e] = this.#i[e].findIndex((s) => i === s.Guid), await this.#a(e);
  }
  #g(t) {
    switch (t?.Group) {
      case S.Wait:
        return t.Type === y.Coupon ? l.AssignCoupon : l.Wait;
      case S.Suppress:
        return l.SuppressFlow;
      case S.Request:
        return t.Type === y.PrefetchFont ? l.PrefetchFont : l.PreFetch;
      case S.Render:
        return t.Type === y.ContentRender || t.Type === y.SpinnerRender ? l.ContentRender : l.ButtonRender;
      case S.Exit:
        return l.Exit;
      case S.Split:
        return t.Type === y.RandomSplit ? l.RandomSplit : l.ConditionSplit;
      default:
        return null;
    }
  }
}
class _e extends m {
  #t;
  #e = "PopupFlow.PrefetchService";
  constructor(t, e) {
    super(t, {
      [l.PreFetch]: async (i) => await this.#i(i)
    }), this.#t = e;
  }
  async #i(t) {
    const e = t.Payload?.Details?.Properties?.ContentUids;
    e ? (this.#t.AddAnimationPreload(), e.forEach(async (i) => {
      try {
        await this.#t.GetDataAsync(t.Payload?.Details?.Properties?.PopupFlowUid, i);
      } catch (s) {
        u(s, this.#e);
      }
    })) : u(new Error(`Popup content UID for flow ${t.Payload.PopupFlowUid} could not be found`), this.#e);
  }
}
class Ve extends m {
  #t;
  #e = "PopupFlow.PrefetchFontService";
  constructor(t, e) {
    super(t, {
      [l.PrefetchFont]: async (i) => await this.#i(i)
    }), this.#t = e;
  }
  async #i(t) {
    if (t.Payload?.Details?.Properties?.Fonts)
      try {
        await this.#t.AddFonts(t);
      } catch (e) {
        u(e, this.#e);
      }
    else
      u(new Error(`Popup fonts for flow ${t.Payload.PopupFlowUid} could not be found`), this.#e);
  }
}
class ze extends m {
  #t = {};
  constructor(t) {
    super(t, {
      [l.Wait]: { [y.WaitTime]: async (e) => await this.#e(e) },
      [l.Exit]: async (e) => await this.#i(e)
    });
  }
  #e(t) {
    const e = t.Payload.Details, i = t.Payload.FlowUid;
    this.#s(i);
    const s = window.setTimeout(() => {
      this.PostMessage({ Type: l.WaitComplete, Payload: { Uid: i } });
    }, e.Properties?.Delay * 1e3);
    this.#t[i] = s;
  }
  #i(t) {
    const e = t.Payload.Uid;
    this.#s(e);
  }
  #s(t) {
    if (t in this.#t) {
      const e = this.#t[t];
      window.clearTimeout(e), delete this.#t[t];
    }
  }
}
class Je extends HTMLElement {
  constructor() {
    super(), this.Uuid = null, this.#e = null, this.#i = 600, this.#s = 5, this.#o = 3500, this.#n = 2e3, this.#r = !1, this.#t = this.attachShadow({ mode: "open", delegatesFocus: !0 });
  }
  #t;
  #e;
  #i;
  #s;
  #o;
  #n;
  #r;
  connectedCallback() {
    this.#a(), window.IntersectionObserver !== void 0 && new IntersectionObserver(
      (t, e) => {
        for (const i of t)
          i.isIntersecting && (this.incentiveContainerWidth && (this.#i = this.incentiveContainerWidth, this.#a()), e.disconnect());
      },
      { threshold: 0.1 }
    ).observe(this);
  }
  get incentiveContainerWidth() {
    return this.#t.querySelector(".spinner-popup__container")?.getBoundingClientRect().width;
  }
  set options(t) {
    this.#e = t, this.Uuid = t?.Spinner?.Uuid, this.setAttribute("uuid", this.Uuid);
  }
  get options() {
    return this.#e;
  }
  get incentivesMarkup() {
    return this.#e?.Spinner?.Incentives?.map((t, e) => {
      const i = this.#e?.Spinner?.Incentives?.length ?? 2, s = 360 / i, n = e * s, r = this.#i, a = i === 2, c = r / 2, h = s / 2, d = a ? r : Math.ceil(2 * c * Math.tan(h * Math.PI / 180)) + 2, p = a ? "none" : "polygon(50% 100%, 0 0, 100% 0)";
      return `
        <div class="listrak-spinner-incentive" style="
            transform: rotate(${n}deg);
            --ltk-bg-color: ${t.BackgroundColor};
            --ltk-wedge-width: ${d}px;
            --ltk-clip-path: ${p};
            --ltk-font-family: ${t.Font.Name};
            --ltk-font-color: ${t.FontColor};
        ">
            ${t.Text}
        </div>
      `;
    }).join("");
  }
  get incentiveFontSize() {
    const t = this.#e?.Spinner?.Incentives?.length ?? 2;
    return t < 4 ? "2rem" : t < 7 ? "1.66rem" : "1.3333rem";
  }
  get dynamicStyles() {
    const t = this.#e?.Spinner, e = t?.Incentives?.length ?? 2, i = 360 / e, s = ((t?.WinnerIndex ?? 0) + 1 + e) % e * i, n = this.#s * 360, r = this.#e?.Container.BackgroundColor;
    let a = this.#e?.Container?.BorderWidth;
    return a > 30 && (a = 30), `
            .listrak-spinner-popup {
              display: block;
              margin: auto;
              width: 600px;
              aspect-ratio: 1;
              position: relative;
            }

            .listrak-spinner-popup__container {
              height: 100%;
              width: 100%;
              box-sizing: border-box;
              border: ${a}px solid ${r};
              background-color: ${r};
              display: flex;
              align-items: center;
              justify-content: center;
              position: relative;
              border-radius: 50%;
              overflow: hidden;
            }

            .triangle {
              width: 0;
              height: 0;
              border-left: 20px solid transparent;
              border-right: 20px solid transparent;
              left: 0;
              right: 0;
              margin: auto;
              position: absolute;
            }

            .triangle.up {
              border-bottom: 27px solid ${r};
              top: -24px;
            }

            .triangle.down {
              border-top: 27px solid ${r};
              top: ${(a ?? 1) - 1}px;
              z-index: 1;
            }

            .listrak-spinner-popup__container__incentives {
              height: 100%;
              width: 100%;
              position: absolute;
              top: 0;
              bottom: 0;
              left: 0;
              right: 0;
              margin: auto;
              transform: rotate(${s}deg);
            }

            .listrak-spinner-incentive {
              padding-top: 9.85%;
              box-sizing: border-box;
              width: fit-content;
              height: 50%;
              position: absolute;
              top: 0;
              left: 0;
              right: 0;
              margin: auto;
              transform-origin: bottom;
              font-family: var(--ltk-font-family);
              color: var(--ltk-font-color);
              font-size: ${this.incentiveFontSize};
            }

            .listrak-spinner-incentive::before {
              content: "";
              position: absolute;
              top: 0;
              left: 50%;
              transform: translateX(-50%);
              width: var(--ltk-wedge-width);
              height: 100%;
              background: var(--ltk-bg-color);
              clip-path: var(--ltk-clip-path);
              z-index: -1;
            }

            .listrak-spinner-popup__container__inner {
              display: flex;
              align-items: center;
              justify-content: center;
              width: 307px;
              height: 307px;
              position: absolute;
              top: 0;
              bottom: 0;
              right: 0;
              left: 0;
              margin: auto;
              flex-direction: column;
              gap: 16px;
              background-color: ${r};
              border-radius: 50%;
            }

            .listrak-spinner-popup__container__inner__heading {
              margin: 0;
              max-width: 224px;
              text-align: center;
              font-size: 1.5rem;
              font-family: ${t?.Heading?.Font.Name};
              color: ${t?.Heading?.FontColor};
            }

            .listrak-spinner-popup__container__inner__action-button {
              line-height: 35px;
              font-weight: 700;
              text-align: center;
              padding: 11px 21px;
              min-width: 205px;
              font-size: 24px;
              font-family: ${t?.ActionButton?.Font.Name};
              color: ${t?.ActionButton?.FontColor};
              border-radius: ${t?.ActionButton?.BorderRadius}px;
              background-color: ${t?.ActionButton?.BackgroundColor};
              border: none;
              transition: 85ms ease-in-out;
              cursor: pointer;
            }

            .listrak-spinner-popup__container__inner__action-button:hover {
              background-color: ${t?.ActionButton?.BackgroundHoverColor};
            }

            .listrak-spinner-popup__container__inner__dismiss {
              font-size: 21px;
              background-color: transparent;
              color: ${t?.Dismiss?.FontColor};
              font-family: ${t?.Dismiss?.Font.Name};
              border: none;
              cursor: pointer;
              text-decoration: underline;
            }

            @keyframes spinWheel {
              from {
                  transform: rotate(${s}deg);
              }
              to {
                  transform: rotate(${n}deg);
              }
            }

            .spin {
              animation: spinWheel ${this.#o}ms cubic-bezier(0.33, 1, 0.68, 1) forwards;
            }

            @media only screen and (max-width: ${this.#e?.Container.MobileBreakpoint}px) {
              .listrak-spinner-popup {
                transform: scale(0.53) translate(-44%, -246px);
              }
            }
        `;
  }
  #l() {
    const t = this.#t.querySelector(".listrak-spinner-popup__container__inner__action-button"), e = this.#t.querySelector(".listrak-spinner-popup__container__inner__dismiss"), i = this.Uuid;
    t?.addEventListener("click", () => {
      if (this.#r)
        return;
      this.#r = !0, this.#t.querySelector(".listrak-spinner-popup__container__incentives")?.classList.add("spin");
      const s = new CustomEvent("spin-click", { bubbles: !0, composed: !0, detail: { Source: t } });
      this.dispatchEvent(s), t.blur(), setTimeout(() => {
        const n = new CustomEvent("spin-complete", { bubbles: !0, composed: !0, detail: { value: i } });
        this.dispatchEvent(n);
      }, this.#o + this.#n);
    }), e?.addEventListener("click", () => {
      const s = new CustomEvent("spin-cancel", { bubbles: !0, composed: !0, detail: { value: i } });
      e.blur(), this.dispatchEvent(s);
    });
  }
  #a() {
    this.#t.innerHTML = `
        <style>${this.dynamicStyles}</style>
        <div class="listrak-spinner-popup">
            <div class="triangle down"></div>
            <div class="listrak-spinner-popup__container">
                <div class="listrak-spinner-popup__container__incentives">
                    ${this.incentivesMarkup}
                </div>
                <div class="listrak-spinner-popup__container__inner">
                    <div class="triangle up"></div>
                    <h3 class="listrak-spinner-popup__container__inner__heading" id="heading">${this.#e?.Spinner?.Heading?.Text}</h3>
                    <button class="listrak-spinner-popup__container__inner__action-button" id="action-button" role="button" tabindex="0">${this.#e?.Spinner?.ActionButton?.Text}</button>
                    <button class="listrak-spinner-popup__container__inner__dismiss" role="button" id="dismiss-button" tabindex="0">${this.#e?.Spinner?.Dismiss?.Text}</button>
                </div>
            </div>
        </div>
    `, this.#l();
  }
}
function qe() {
  customElements.get("listrak-spinner-popup") || customElements.define("listrak-spinner-popup", Je);
}
function Qe(o) {
  const t = document.createElement("listrak-spinner-popup");
  return t.options = o, t;
}
class je extends m {
  #t;
  #e;
  #i;
  #s = "PopupFlow.PopupIntegrationService";
  #o = null;
  #n;
  constructor(t, e, i, s, n, r) {
    super(t, {
      [l.OpenContent]: async (a) => await this.#r(a),
      [l.CloseContent]: async (a) => await this.#l(a)
    }), this.#t = e, this.#e = i, this.#i = r, this.#o = s, this.#n = n;
  }
  async #r(t) {
    const e = t.Payload;
    if (!e) {
      console.log("Invalid or empty popup content sent to open content");
      return;
    }
    const i = e.ActivityUid, s = {
      Uuid: e.Uuid ?? e.StepUid,
      CloseOptions: e.CloseOptions ?? {},
      PopupSettings: e.PopupSettings ?? null,
      Animation: e.Animation ?? "none",
      UseShadowDom: e.UseShadowDom ?? !0,
      Browser: this.#n
    };
    if (e.PopupSettings?.Spinner) {
      const a = s.PopupSettings?.Spinner?.Heading?.Font, c = s.PopupSettings?.Spinner?.Heading?.Font, h = s.PopupSettings?.Spinner?.Dismiss?.Font, d = s.PopupSettings?.Spinner?.Incentives?.[0]?.Font, p = [
        a,
        c,
        h,
        d
      ].filter((g) => g?.Url).map((g) => ({
        Url: g?.Url,
        FontFamily: g?.Family
      }));
      p.length && this.PostMessage({
        Type: l.PrefetchFont,
        Payload: {
          Details: {
            Properties: {
              Fonts: p
            }
          }
        }
      });
    }
    const n = this.#t.CreatePopup(s);
    e.CustomFonts !== void 0 && e.CustomFonts !== null && e.CustomFonts.length !== 0 && this.#h(n, e.CustomFonts);
    const r = {
      Html: e.Content.Html ?? "",
      ...e.Content.Js ? { Js: e.Content.Js } : {}
    };
    if (e.PopupSettings?.Spinner) {
      qe(), e.PopupSettings.Spinner.Uuid = n.Uuid;
      const a = Qe(e.PopupSettings);
      n.shadowRoot?.querySelector("slot")?.appendChild(a), this.#c(e.FlowUid, n, i);
    } else
      n.InsertContent(r);
    this.#a(e.FlowUid, n, i), e.SubscriberFormOptions && this.#e.AttachSubscriptionFormTriggers(e.FlowUid, e.Uuid, n, e.SubscriberFormOptions, i), this.#t.OpenPopup(e.Uuid ?? e.StepUid);
  }
  async #l(t) {
    const e = t.Payload;
    if (!e) {
      console.log("Invalid or empty popup uuid sent to close content");
      return;
    }
    this.#t.ClosePopup(e);
  }
  #a(t, e, i) {
    e.addEventListener("popup-close", (s) => {
      this.PostMessage({ Type: l.Exit, Payload: { Uid: t, Source: s?.detail?.Source } });
    }), e.addEventListener("link-click", (s) => {
      const n = s?.detail?.Link;
      this.#i.RecordClick(t, n, i), this.PostMessage({ Type: l.LinkClick, Payload: { Uid: t, PopupUid: e.Uuid, Url: n, StepUid: i } });
    });
  }
  #c(t, e, i) {
    e.addEventListener("spin-click", () => {
      this.PostMessage({ Type: l.SpinClick, Payload: { Uid: t, StepUid: i } });
    }), e.addEventListener("spin-complete", (s) => {
      this.#t.ClosePopup(s?.detail?.value), this.PostMessage({ Type: l.WaitComplete, Payload: { Uid: t } });
    }), e.addEventListener("spin-cancel", (s) => {
      this.#t.ClosePopup(s?.detail?.value);
    });
  }
  #h(t, e) {
    let i = 0;
    if (this.#o?.fonts.forEach((s) => {
      e.some((n) => n.FontFamily === s.family) && i++;
    }), i !== e.length) {
      t.style.opacity = "0";
      const s = setTimeout(() => {
        t.style.removeProperty("opacity");
      }, 1e3);
      this.#o?.fonts.addEventListener("loading", () => {
        this.#n.Device.IsIOSDevice() || clearTimeout(s);
      }), this.#o?.fonts.addEventListener("loadingdone", () => {
        t.style.removeProperty("opacity");
      }), this.#o?.fonts.addEventListener("loadingerror", () => {
        t.style.removeProperty("opacity");
        const n = new Error("Error loading custom font");
        throw u(n, this.#s), n;
      });
    }
  }
}
const Y = "ltk-popup-flow-whitelist";
class Ke extends m {
  #t;
  constructor(t) {
    super(t, {
      [l.Any]: async (i) => await this.#e(i)
    });
    const e = window.localStorage.getItem(Y);
    this.#t = e ? JSON.parse(e) : null;
  }
  #e(t) {
    this.#t && (this.#t.length === 0 || t.Type != null && this.#t.includes(t.Type.toString())) && console.log("FlowEngine:", t.Type, t.Payload);
  }
  EnableDebug() {
    this.#t = [], window.localStorage.setItem(Y, JSON.stringify(this.#t));
  }
  IsDebugEnabled(t) {
    return this.#t && this.#t.length === 0 ? !0 : t && this.#t?.includes(t) || !1;
  }
}
class Ze {
  constructor(t, e) {
    this.#t = e, this.Container = this.#e(t), this.Overlay = this.#i(t), this.Popup = this.#s(t), this.Spinner = this.#o(t);
  }
  #t = !1;
  #e(t) {
    if (!t)
      return {
        CloseButtonLocation: "top-right",
        CloseButtonColor: "#000000",
        PagePlacement: "center",
        BorderWidth: 0,
        BackgroundColor: "#FFFFFF",
        MobileBreakpoint: void 0,
        MobileMaxWidth: void 0,
        TransparentBrackground: void 0,
        ContainerWidth: void 0
      };
    if (this.#t)
      return {
        MobileBreakpoint: 600,
        MobileMaxWidth: 320,
        TransparentBrackground: !0,
        ContainerWidth: 600,
        ...t.Container
      };
    const {
      CloseButtonLocation: e = "top-right",
      CloseButtonColor: i = "#000000",
      PagePlacement: s = "center",
      BorderWidth: n = 0,
      PopupBackgroundColor: r = "#FFFFFF"
    } = t;
    return {
      MobileBreakpoint: void 0,
      MobileMaxWidth: void 0,
      TransparentBrackground: void 0,
      ContainerWidth: void 0,
      CloseButtonLocation: e,
      CloseButtonColor: i,
      PagePlacement: s,
      BorderWidth: n,
      BackgroundColor: r
    };
  }
  #i(t) {
    if (!t)
      return {
        Color: "#000000",
        Opacity: 0.5
      };
    if (this.#t) {
      const { Overlay: e } = t;
      return {
        Color: e.OverlayColor,
        Opacity: e.OverlayTransparency
      };
    } else {
      const { OverlayColor: e = "#000000", OverlayTransparency: i = 0.5 } = t;
      return { Color: e, Opacity: i };
    }
  }
  #s(t) {
    if (!t || this.#t)
      return null;
    const {
      PopupShape: e,
      PopupWidth: i,
      PopupHeight: s,
      BorderRadius: n,
      BorderStyle: r,
      BorderColor: a,
      PopupBackgroundImage: c,
      PopupBackgroundImageSize: h,
      PopupBackgroundImagePosition: d,
      PopupBackgroundImageRepeat: p
    } = t;
    return {
      Shape: e,
      Width: i,
      Height: s,
      BorderRadius: n,
      BorderStyle: r,
      BorderColor: a,
      BackgroundImage: c,
      BackgroundImageSize: h,
      BackgroundImagePosition: d,
      BackgroundImageRepeat: p
    };
  }
  #o(t) {
    if (!t)
      return null;
    if (this.#t) {
      const e = t;
      return {
        BackgroundColor: e.Container?.BackgroundColor,
        Heading: e.Heading,
        ActionButton: e.ActionButton,
        Dismiss: e.Dismiss,
        Incentives: e.Incentives,
        WinnerIndex: 0,
        Uuid: e.Uuid
      };
    }
    return null;
  }
  get settings() {
    return {
      Container: this.Container,
      Overlay: this.Overlay,
      ...this.Popup && { Popup: this.Popup },
      ...this.Spinner && { Spinner: this.Spinner }
    };
  }
}
class Xe extends m {
  #t;
  #e;
  constructor(t, e, i) {
    super(t, {
      [l.ContentRender]: async (s) => await this.#i(s)
    }), this.#t = 5, i !== void 0 && (this.#t = i), this.#e = e;
  }
  async #i(t) {
    const e = t.Payload?.Details?.Properties?.ContentUid, i = t.Payload?.FlowUid, s = t.Payload?.Guid, n = t.Payload?.Details?.Properties?.ActivityUid, r = ct + e, a = this.#e.GetTags(i);
    if (t.Payload?.Details?.Type === y.SpinnerRender) {
      this.#s(t, i, e, s, y.SpinnerRender, n);
      return;
    }
    let c = 0;
    for (; c < this.#t || c === 0; ) {
      const h = window.sessionStorage.getItem(r);
      if (h) {
        const d = JSON.parse(h), p = d.js ?? null;
        let g = d.html;
        a && (g = this.#o(g, a)), this.#s(t, i, e, s, y.ContentRender, n, g, p);
        break;
      } else
        c++, c <= this.#t && await new Promise((d) => setTimeout(d, 2e3)), console.log("Popup content is not available.");
    }
  }
  #s(t, e, i, s, n, r, a = "", c) {
    const h = n === y.SpinnerRender ? t.Payload?.Details?.Properties?.SpinnerSettings : t.Payload?.Details?.Properties?.PopupSettings, d = new Ze(h, n === y.SpinnerRender).settings, p = {
      FlowUid: e,
      StepUid: s,
      ActivityUid: r,
      Uuid: i,
      Content: {
        Html: a,
        ...c ? { Js: c } : {}
      },
      CloseOptions: {
        OnOverlayClick: t.Payload?.Details?.Properties?.OverlayClose ?? !1
      },
      PopupSettings: d,
      SubscriberFormOptions: {
        SubscriberFormContent: t.Payload?.Details?.Properties.SubscriberFormData ?? []
      },
      Animation: t.Payload?.Details?.Properties?.Animation,
      CustomFonts: t.Payload?.Details?.Properties?.CustomFonts
    };
    this.PostMessage({
      Type: l.OpenContent,
      Payload: p
    });
  }
  #o(t, e) {
    for (let i = 0; i < 25; i++) {
      let s = !1;
      for (const n in e)
        t.indexOf(n) !== -1 && (t = t.replace(n, e[n]), s = !0);
      if (!s)
        break;
    }
    return t;
  }
}
var O = /* @__PURE__ */ ((o) => (o.DefaultShowAgainAfter = "ltk-suppress-", o))(O || {});
class Ye extends m {
  #t;
  constructor(t, e) {
    super(t, {
      [l.SuppressFlow]: async (i) => await this.#e(i)
    }), this.#t = e;
  }
  SetSuppression(t, e, i) {
    const s = /* @__PURE__ */ new Date(), n = /* @__PURE__ */ new Date();
    n.setDate(n.getDate() + i), this.#t.Cookie.SetCookie(t + e, s.toUTCString(), n, void 0, "/");
  }
  async #e(t) {
    const e = t.Payload?.Details?.Properties || t.Payload;
    if (!e) {
      console.log("Invalid or empty request sent to Suppression Service");
      return;
    }
    const i = e.CookieKey || O.DefaultShowAgainAfter;
    this.SetSuppression(i, e.FlowUid, e.Days);
  }
}
class ti extends m {
  #t;
  // desktop trigger settings
  #e = {};
  #i = {};
  #s = {};
  #o = 0.1;
  #n = {};
  #r = {};
  // mobile trigger settings
  #l = {};
  #a = 0.3;
  #c = {};
  constructor(t, e) {
    super(t, {
      [l.Wait]: { [y.WaitExit]: async (i) => await this.#h(i) }
    }), this.#t = e;
  }
  #h(t) {
    const e = t.Payload.FlowUid;
    this.#t.Device.GetType() === this.#t.Device.Types.Desktop ? this.#u(e) : this.#p(e);
  }
  #u(t) {
    this.#d(t), this.#e[t] = !1, this.#i[t] = !1, this.#s[t] = null, this.#n[t] = this.#S(t), this.#r[t] = this.#b(t), this.#t.Mouse.AddMouseMoveListener(this.#n[t]), this.#t.Mouse.AddMouseOutListener(this.#r[t]);
  }
  #d(t) {
    t in this.#n && (this.#t.Mouse.RemoveMouseMoveListener(this.#n[t]), delete this.#n[t]), t in this.#r && (this.#t.Mouse.RemoveMouseOutListener(this.#r[t]), delete this.#r[t]);
  }
  #p(t) {
    this.#g(t), this.#l[t] = !1, this.#c[t] = this.#v(t), this.#t.Scroll.AddScrollListener(this.#c[t]);
  }
  #g(t) {
    t in this.#c && (this.#t.Scroll.RemoveScrollListener(this.#c[t]), delete this.#c[t]);
  }
  // desktop trigger methods
  #f(t, e) {
    return this.#e[t] = this.#e[t] || e > this.#y(), this.#e[t];
  }
  #y() {
    return this.#t.Window.GetVisibleHeight() * this.#o;
  }
  #S(t) {
    return (e) => {
      const i = this.#t.Mouse.GetMouseEventY(e);
      this.#f(t, i) && this.#w(t, i);
    };
  }
  #w(t, e) {
    this.#s[t] ? (this.#m(t, e), this.#s[t] = e) : e >= 0 && (this.#s[t] = e);
  }
  #m(t, e) {
    this.#C(t, e) && (this.#i[t] = !0);
  }
  #C(t, e) {
    const i = this.#s[t];
    return i !== null && i < this.#y() && e < i;
  }
  #b(t) {
    return (e) => {
      if (this.#i[t]) {
        const i = this.#t.Mouse.GetMouseEventY(e), s = this.#t.Mouse.GetMouseEventX(e), n = this.#t.Window.GetVisibleWidth();
        i <= 5 && s < n && (this.PostMessage({ Type: l.WaitComplete, Payload: { Uid: t } }), this.#d(t));
      }
    };
  }
  // mobile trigger methods
  #v(t) {
    return (e) => {
      this.#k(t) && this.#t.Scroll.GetDepthFraction() === 0 && (this.PostMessage({ Type: l.WaitComplete, Payload: { Uid: t } }), this.#g(t));
    };
  }
  #k(t) {
    return this.#l[t] = this.#l[t] || this.#t.Scroll.GetDepthFraction() >= this.#a, this.#l[t];
  }
}
class ei extends m {
  #t = {};
  #e = "Bottom";
  #i = {};
  #s;
  constructor(t, e) {
    super(t, {
      [l.Wait]: { [y.WaitScroll]: async (i) => await this.#o(i) }
    }), this.#s = e;
  }
  #o(t) {
    const e = t.Payload.Details, i = t.Payload.FlowUid;
    let s = 1;
    e.Properties?.CustomScrollDepth !== void 0 && e.Properties?.CustomScrollDepth !== null ? s = e.Properties?.CustomScrollDepth / 100 : s = e.Properties?.ScrollDepth === this.#e ? 1 : 0.5, this.#t[i] = s, this.#n(i);
  }
  #n(t) {
    this.#a() && (this.#r(t), this.#i[t] = this.#l(t), this.#s.Scroll.AddScrollListener(this.#i[t]));
  }
  #r(t) {
    t in this.#i && (this.#s.Scroll.RemoveScrollListener(this.#i[t]), delete this.#i[t]);
  }
  #l(t) {
    return (e) => {
      const i = this.#s.Scroll.GetDepthFraction(), s = this.#t[t];
      s >= 0.99 ? (i >= 0.99 || this.#c()) && (this.PostMessage({ Type: l.WaitComplete, Payload: { Uid: t } }), this.#r(t)) : i >= s && (this.PostMessage({ Type: l.WaitComplete, Payload: { Uid: t } }), this.#r(t));
    };
  }
  #a() {
    return this.#s.Document.GetTotalHeight() / this.#s.Window.GetVisibleHeight() >= 2;
  }
  #c() {
    return this.#s.Document.GetTotalHeight() - this.#s.Window.GetVisibleHeight() - this.#s.Scroll.GetDepthPixels() <= 100;
  }
}
class ii {
  #t = [];
  AddEvaluator(t) {
    this.#t.push(t);
  }
  GetWinner(t) {
    return t.find((e) => this.#e(e));
  }
  DebugWinner(t) {
    return t.map((e) => this.#i(e));
  }
  #e(t) {
    for (let e = 0; e < this.#t.length; e++)
      if (!this.#t[e].Evaluate(t))
        return !1;
    return !0;
  }
  #i(t) {
    const e = [];
    for (let i = 0; i < this.#t.length; i++) {
      const s = this.#t[i].DebugEvaluate(t);
      if (e.push(s), !s.Passes)
        return {
          TargetingDefinition: t,
          Passes: !1,
          InnerEvals: e
        };
    }
    return {
      TargetingDefinition: t,
      Passes: !0,
      InnerEvals: e
    };
  }
}
class si {
  #t = "Suppression";
  #e;
  constructor(t) {
    this.#e = t;
  }
  GetSuppression(t) {
    return this.#e.Cookie.GetCookie(O.DefaultShowAgainAfter + t) !== "";
  }
  Evaluate(t) {
    return t.Uid ? !this.GetSuppression(t.Uid) : !0;
  }
  DebugEvaluate(t) {
    return {
      Name: this.#t,
      Passes: this.Evaluate(t)
    };
  }
}
class oi {
  #t = "SessionDepth";
  #e;
  constructor(t) {
    this.#e = t;
  }
  Evaluate(t) {
    return t.TargetingRuleSet?.SessionDepth ? this.#i(t.TargetingRuleSet?.SessionDepth) : !0;
  }
  DebugEvaluate(t) {
    return {
      Name: this.#t,
      Passes: this.Evaluate(t)
    };
  }
  #i(t) {
    return this.#e.Session.GetSessionDepth() >= t;
  }
}
var L = /* @__PURE__ */ ((o) => (o.GoToNextStep = "goToNextStep", o.GoToUrl = "goToUrl", o.ClosePopup = "closePopup", o))(L || {});
class ni extends m {
  #t = 2500;
  #e = 1;
  #i = 2;
  #s;
  #o;
  #n = 13;
  #r = 10;
  constructor(t, e, i) {
    super(t, {}), this.#s = e, this.#o = i;
  }
  AttachSubscriptionFormTriggers(t, e, i, s, n) {
    this.#l(i), this.#a(t, e, i, s, n);
  }
  #l(t) {
    const e = Array.from(t.getElementsByTagName("input"));
    if (t.shadowRoot) {
      const i = t.shadowRoot.getElementById("ltk-popup-inner");
      i && e.push(...Array.from(i.getElementsByTagName("input")));
    }
    e.length <= 0 || e.forEach((i) => {
      i.type === "tel" && (i.addEventListener("keydown", (s) => this.#y(s)), i.addEventListener("keyup", (s) => this.#S(s)));
    });
  }
  #a(t, e, i, s, n) {
    const r = Array.from(i.getElementsByTagName("form"));
    if (i.shadowRoot) {
      const c = i.shadowRoot.getElementById("ltk-popup-inner");
      c && r.push(...Array.from(c.getElementsByTagName("form")));
    }
    if (r.length <= 0)
      return;
    const a = s.SubscriberFormContent;
    for (let c = 0; c < Math.min(r.length, a.length); c++) {
      const h = r[c], d = a[c], p = h.querySelector('input[name="phone"]'), g = h.querySelector('input[name="email"]');
      p?.addEventListener("input", () => {
        p?.setCustomValidity("");
      }), g?.addEventListener("input", () => {
        g?.setCustomValidity("");
      }), h.addEventListener("submit", async (v) => {
        await this.#c(v, t, e, d, n);
      });
    }
  }
  async #c(t, e, i, s, n) {
    t.preventDefault();
    let r = !1;
    const a = this.#b(s.Channels), c = this.#w(t, 'input[name="email"]'), h = this.#w(t, 'input[name="phone"]'), d = t.target, p = d.querySelector('input[name="email"]'), g = d.querySelector('input[name="phone"]');
    if (p && (Le(p.value) || !p.required && p.value === "" ? p.setCustomValidity("") : (r = !0, p.setCustomValidity("Please enter a valid email address."))), g && (Me(g.value) || !g.required && g.value === "" ? g.setCustomValidity("") : (r = !0, g.setCustomValidity("Please enter a valid phone number."))), a.EmailCode && !r && await this.#h(d, a.EmailCode, s, h, c), a.SmsCode && !r && await this.#u(d, a.SmsCode, s, h, c), r)
      d.reportValidity();
    else {
      const v = { Email: a.EmailCode !== null, Sms: a.SmsCode !== null }, P = this.#m(d);
      return this.#o.RecordSubmit(e, P, n), this.PostMessage({ Type: l.FormSubmission, Payload: { Uid: e, Channels: v, FormFields: P, StepUid: n } }), !s.Action || s.Action === L.GoToUrl ? (s.RedirectUrl && (this.PostMessage({ Type: l.UrlRedirect, Payload: { Uid: e, Url: s.RedirectUrl } }), window.setTimeout(function() {
        window.open(s.RedirectUrl ?? "");
      }, this.#t)), this.PostMessage({ Type: l.CloseContent, Payload: i }), this.PostMessage({ Type: l.Exit, Payload: { Uid: e } })) : s.Action === L.ClosePopup ? (this.PostMessage({ Type: l.CloseContent, Payload: i }), this.PostMessage({ Type: l.Exit, Payload: { Uid: e } })) : s.Action === L.GoToNextStep && (this.PostMessage({ Type: l.CloseContent, Payload: i }), this.PostMessage({ Type: l.WaitComplete, Payload: { Uid: e } })), !1;
    }
    return !0;
  }
  async #h(t, e, i, s, n) {
    if (n === null || n?.length <= 0)
      return;
    const r = {
      SubscribeChannel: "Email",
      SubscribeType: "s",
      ResetSubscribeState: !1,
      Identifier: n,
      UpdatedIdentifier: null,
      List: e,
      Settings: null,
      ModalUID: null,
      ProfileItems: []
    };
    this.#p(t, this.#e, i).forEach((a) => {
      r.ProfileItems.push({ AttributeId: a.Name, AttributeValue: a.Value });
    }), s && s.length > 0 && i.FieldMappings && this.#d(i.FieldMappings.phone, this.#e) && r.ProfileItems.push({ AttributeId: "phone", AttributeValue: s }), await this.#s.SubmitSubscribeDataAsync(r);
  }
  async #u(t, e, i, s, n) {
    if (!s || s?.length <= 0)
      return;
    const r = {
      SubscribeChannel: "SMS",
      SubscribeType: "s",
      ResetSubscribeState: !1,
      Identifier: s,
      UpdatedIdentifier: null,
      List: e,
      Settings: null,
      ModalUID: null,
      ProfileItems: []
    };
    r.Identifier = s, r.List = e, this.#p(t, this.#i, i).forEach((a) => {
      r.ProfileItems.push({ AttributeId: a.Name, AttributeValue: a.Value });
    }), n && n.length > 0 && i.FieldMappings && this.#d(i.FieldMappings.email, this.#i) && r.ProfileItems.push({ AttributeId: "email", AttributeValue: n }), await this.#s.SubmitSubscribeDataAsync(r);
  }
  #d(t, e) {
    return (t & e) === e;
  }
  #p(t, e, i) {
    const s = [];
    return (this.#C(t, 'input[name^="Field_"],textarea[name^="Field_"],select[name^="Field_"]') ?? []).forEach((n) => {
      const r = n.name;
      if (!r || !e || !i.FieldMappings || this.#d(i.FieldMappings[r], e)) {
        const a = n.type;
        let c;
        a === "checkbox" ? c = n.checked ? "on" : null : a === "radio" ? n.checked && (c = n.value) : c = n.value, c != null && c !== "" && s.push({ Name: r, Value: c });
      }
    }), s;
  }
  #g(t) {
    return /^\d$/.test(t.key);
  }
  #f(t) {
    const e = t.key, i = ["Home", "End", "Backspace", "Tab", "Enter", "Delete", "ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"], s = ["A", "C", "V", "X", "Z"];
    return i.includes(e) || t.ctrlKey && s.includes(e.toUpperCase());
  }
  #y(t) {
    !this.#g(t) && !this.#f(t) && t.preventDefault();
  }
  #S(t) {
    if (this.#f(t))
      return;
    const e = t.target, i = e.value.replace(/\D/g, "").slice(0, this.#n), s = i.length, n = s > this.#r, r = n ? s - this.#r : 0, a = n ? "+" + i.slice(0, r) : "", c = i.slice(r), h = c.substring(0, 3), d = c.substring(3, 6), p = c.substring(6, 10);
    i.length > 6 ? e.value = "(" + h + ") " + d + "-" + p : i.length > 3 ? e.value = "(" + h + ") " + d : i.length > 0 && (e.value = "(" + h), a && (e.value = `${a} ${e.value}`);
  }
  #w(t, e) {
    const i = t.target.querySelector(e);
    return i && i.value.length >= 0 ? i.value : null;
  }
  #m(t) {
    const e = {};
    return t.querySelectorAll("input,textarea,select").forEach((i) => {
      const s = i.name;
      s && (i instanceof HTMLInputElement ? i.type === "checkbox" ? e[s] = i.checked ? "on" : "off" : i.type === "radio" ? i.checked && (e[s] = i.value) : e[s] = i.value : e[s] = i.value);
    }), e;
  }
  #C(t, e) {
    return t.querySelectorAll(e);
  }
  #b(t) {
    return { EmailCode: t?.EmailChannel?.SubscriberCode ?? null, SmsCode: t?.SmsChannel?.SubscriberCode ?? null };
  }
}
class ri extends m {
  constructor(t, e, i, s) {
    super(t, {
      [l.ButtonRender]: async (n) => await this.#o(n),
      [l.Exit]: async (n) => await this.#l(n)
    }), this.ButtonElementName = "listrak-button-element", this.#t = null, this.#i = {}, window.customElements.get(this.ButtonElementName) || window.customElements.define(this.ButtonElementName, e), this.#e = e, this.#s = i, this.#t = s;
  }
  #t;
  #e;
  #i;
  #s;
  #o(t) {
    const e = t.Payload?.Details?.Properties, i = t.Payload.FlowUid;
    this.#i[i] || (this.#i[i] = this.#n(i, e));
  }
  #n(t, e) {
    const i = new this.#e();
    return i.Configure(t, e, this.#s, this.#t), i.addEventListener("open-popup", () => {
      this.#r(t);
    }), i.addEventListener("button-hidden", () => {
      e.SuppressionDays && this.PostMessage({ Type: l.SuppressFlow, Payload: { FlowUid: t, Days: e.SuppressionDays } });
    }), this.#t?.body.appendChild(i), i;
  }
  #r(t) {
    this.PostMessage({ Type: l.ButtonClick, Payload: { Uid: t } });
  }
  #l(t) {
    const e = t.Payload.Uid, i = this.#i[e];
    i && this.#s.Cookie.GetCookie(O.DefaultShowAgainAfter + e) === "" && i.SetVisible(!0);
  }
}
class ai extends HTMLElement {
  constructor() {
    super(), this.Uuid = null, this.#t = null, this.#e = "ButtonElement", this.#i = null, this.#s = "listrak-button-container", this.#o = null, this.#n = null;
  }
  #t;
  #e;
  #i;
  #s;
  #o;
  #n;
  // note: these callbacks are not capitalized because they are overriding functions exposed by HTMLElement
  connectedCallback() {
    this.Init(), this.#h();
  }
  disconnectedCallback() {
    this.#u();
  }
  SetStyleSheet(t) {
    if (!this.#t) {
      const i = new Error("Document not configured in button element");
      throw u(i, this.#e), i;
    }
    const e = this.#t.defaultView;
    if (e) {
      const i = new e.CSSStyleSheet();
      if (i.replaceSync(this.GetStyleTemplate(t)), this.shadowRoot)
        this.shadowRoot.adoptedStyleSheets.push(i);
      else {
        const s = new Error("Shadow Root not configured in button element");
        throw u(s, this.#e), s;
      }
    } else {
      const i = new Error("Document view not found");
      throw u(i, this.#e), i;
    }
  }
  GetStyleTemplate(t) {
    const e = t.Container.Image.Source === "" ? "" : this.#p(t.Container.Image), i = t.Container.Height === null ? "auto" : `${t.Container.Height}px`, s = t.Container.Width === null ? "auto" : `${t.Container.Width}px`;
    return `
      ${this.#s} {
        --ltk-button-height: ${i};
        --ltk-button-width: ${s};
        --ltk-button-padding-block: ${t.Container.PaddingBlock}px;
        --ltk-button-padding-inline: ${t.Container.PaddingInline}px;
        --ltk-button-inset-block: ${t.Layout.InsetBlock}px;
        --ltk-button-inset-inline: ${t.Layout.InsetInline}px;
        --ltk-button-bkg-color: ${t?.Container.Color};
        --ltk-button-border-radius: ${t.Container.Border.Radius}px;
        --ltk-button-border:  ${t.Container.Border.Width}px ${t.Container.Border.Style} ${t.Container.Border.Color};
        --ltk-button-font-color: ${t.Type.Color};
        --ltk-button-font-family: ${t.Type.Font.FontFamily};
        --ltk-button-font-size:  ${t.Type.Size}px;
        --ltk-button-font-weight: ${t.Type.Weight};
        --ltk-button-letter-spacing: ${t.Type.Spacing}px;
        --ltk-button-close-color: ${t.Close.Color};
      }

      ${this.#s} {
        background-color: var(--ltk-button-bkg-color);
        display: flex;
        position: fixed;
        z-index: var(--override-button-z-index, calc(infinity));
        pointerEvents: none;
        border: var(--ltk-button-border);
        border-radius: var(--ltk-button-border-radius);
        gap: calc(var(--ltk-button-padding-inline) / 1.5);
        ${e};
      }

      ${this.#s}.hide {
        visibility: hidden
      }

      ${this.#s}.ltk-position-left:not(.ltk-position-top, .ltk-position-bottom),
      ${this.#s}.ltk-position-right:not(.ltk-position-top, .ltk-position-bottom) {
        inset-block-start: 50%;
      }
      ${this.#s}.ltk-position-left:not(.ltk-position-top, .ltk-position-bottom) {
        transform: translate(-50%, -50%) rotate(-90deg) translateY(50%);
      }
      ${this.#s}.ltk-position-right:not(.ltk-position-top, .ltk-position-bottom) {
        transform: translate(50%, -50%) rotate(90deg) translateY(50%);
      }
      ${this.#s}.ltk-position-top:not(.ltk-position-left, .ltk-position-right),
      ${this.#s}.ltk-position-bottom:not(.ltk-position-left, .ltk-position-right) {
        inset-inline-start: 50%;
        transform: translateX(-50%);
      }
      ${this.#s}.ltk-position-top {
        inset-block-start: var(--ltk-button-inset-block);
      }
      ${this.#s}.ltk-position-left {
        inset-inline-start: var(--ltk-button-inset-inline);
      }
      ${this.#s}.ltk-position-right {
        inset-inline-end: var(--ltk-button-inset-inline);
      }
      ${this.#s}.ltk-position-bottom {
        inset-block-end: var(--ltk-button-inset-block);
      }

      ${this.#s} button {
        background: transparent;
        border: none;
        cursor: pointer;
        padding-block: var(--ltk-button-padding-block);
        text-align: var(--ltk-button-text-align);
      }
      ${this.#s} button.display {
        color: var(--ltk-button-font-color);
        font-family: var(--ltk-button-font-family);
        font-size: var(--ltk-button-font-size);
        letter-spacing: var(--ltk-button-letter-spacing);
        font-weight: var(--ltk-button-font-weight);
        height: var(--ltk-button-height);
        width: var(--ltk-button-width);
        padding-inline: var(--ltk-button-padding-inline);
      }
      ${this.#s} button.display.has-close {
        padding-inline-end: calc(var(--ltk-button-padding-inline) / 2);
      }
      ${this.#s} button.close {
        padding-inline-end: var(--ltk-button-padding-inline);
        padding-inline-start: calc(var(--ltk-button-padding-inline) / 2);
      }
      ${this.#s} button svg {
        stroke: var(--ltk-button-close-color);
        stroke-width: 2px;
        width: calc(var(--ltk-button-font-size) * 1.2);
        height: calc(var(--ltk-button-font-size) * 1.2);
        display: block;
      }
    `;
  }
  Configure(t, e, i, s) {
    this.Uuid = t, this.setAttribute("uuid", this.Uuid), this.#t = s, this.#i = e, this.#n = i;
  }
  Init() {
    if (this.#i === null) {
      const i = new Error("Button Settings not configured");
      throw u(i, this.#e), i;
    }
    if (this.attachShadow({ mode: "open" }), this.shadowRoot === null) {
      const i = new Error("ShadowRoot failed to initialize");
      throw u(i, this.#e), i;
    }
    this.#r(this.#i.Type.Font), this.SetStyleSheet(this.#i);
    const t = this.#l(this.#i);
    this.#o = t, this.shadowRoot.appendChild(t);
    const e = this.#a(this.#i);
    if (t.appendChild(e), this.#i.Close.Enabled) {
      const i = this.#c();
      t.appendChild(i);
    }
  }
  SetVisible(t) {
    t ? this.#o?.classList.remove("hide") : this.#o?.classList.add("hide");
  }
  #r(t) {
    if (t.Url !== null) {
      let e = !1;
      if (this.#t?.fonts.forEach((i) => {
        i.family === t.FontFamily && (e = !0);
      }), !e) {
        this.style.opacity = "0";
        let i = !1;
        const s = setTimeout(() => {
          i || this.style.removeProperty("opacity");
        }, 1e3);
        this.#t?.fonts.addEventListener("loading", () => {
          i = !0, clearTimeout(s);
        }), this.#t?.fonts.addEventListener("loadingdone", () => {
          this.style.removeProperty("opacity");
        }), this.#t?.fonts.addEventListener("loadingerror", () => {
          this.style.removeProperty("opacity");
          const n = new Error("Error loading custom font");
          throw u(n, this.#e), n;
        });
      }
    }
  }
  #l(t) {
    if (this.#t === null) {
      const s = new Error("Document not configured");
      throw u(s, this.#e), s;
    }
    const e = this.#t.createElement(this.#s), i = t.Layout.Position.split("-");
    return i.length === 2 && this.#n?.Device.GetType() === this.#n?.Device.Types.Mobile && i.pop(), i.forEach((s) => {
      e.classList.add(`ltk-position-${s}`);
    }), e;
  }
  #a(t) {
    if (this.#t === null) {
      const i = new Error("Document not configured");
      throw u(i, this.#e), i;
    }
    const e = this.#t.createElement("button");
    return e.classList.add("display"), t.Close.Enabled && e.classList.add("has-close"), e.textContent = t.Text, e.addEventListener("click", () => {
      this.SetVisible(!1), this.dispatchEvent(
        new CustomEvent(
          "open-popup",
          {
            bubbles: !0,
            detail: {
              uuid: this.Uuid
            }
          }
        )
      );
    }), e;
  }
  #c() {
    if (this.#t === null) {
      const e = new Error("Document not configured");
      throw u(e, this.#e), e;
    }
    const t = this.#t.createElement("button");
    return t.innerHTML = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30">
    <title id="ltk-popup-button-close-title">Close</title>
    <desc id="ltk-popup-button-close-desc">Closes Web Dialog</desc>
    <line x1="3" y1="3" x2="26" y2="26"></line>
    <line x1="26" y1="3" x2="3" y2="26"></line>
  </svg>
`, t.classList.add("close"), t.addEventListener("click", () => {
      this.SetVisible(!1), this.dispatchEvent(
        new CustomEvent(
          "button-hidden",
          {
            bubbles: !0,
            detail: {
              uuid: this.Uuid
            }
          }
        )
      );
    }), t;
  }
  #h() {
    this.dispatchEvent(
      new CustomEvent(
        "button-connected",
        {
          bubbles: !0,
          detail: {
            uuid: this.Uuid
          }
        }
      )
    );
  }
  #u() {
    this.dispatchEvent(
      new CustomEvent(
        "button-disconnected",
        {
          bubbles: !0,
          detail: {
            uuid: this.Uuid
          }
        }
      )
    );
  }
  #d(t) {
    switch (t) {
      case "top-left":
        return "0% 0%";
      case "bottom-left":
        return "0% 100%";
      case "top-right":
        return "100% 0%";
      case "bottom-right":
        return "100% 100%";
      case "top-center":
        return "top";
      case "bottom-center":
        return "bottom";
      default:
        return t;
    }
  }
  #p(t) {
    return `
      background-image: ${t.Source};
      background-position: ${this.#d(t.Position)};
      background-repeat: ${t.Repeat};
      background-size: ${t.Size};
    `;
  }
}
var k = /* @__PURE__ */ ((o) => (o.EntryImpression = "entry-impression", o.Submission = "submission", o.PersistentButtonClick = "persistent-button-click", o.UrlRedirect = "url-redirect", o.LinkClick = "link-click", o.TapToJoin = "tap-to-join", o.ExitClick = "exit-click", o.ContentImpression = "content-impression", o.CouponImpression = "coupon-impression", o.SplitImpression = "split-impression", o.SpinnerClick = "spinner-click", o))(k || {});
class li extends m {
  #t;
  #e;
  #i;
  #s = "PopupFlow.ActivityTracking";
  #o = {};
  #n;
  constructor(t, e, i, s, n) {
    super(t, {
      [l.FormSubmission]: async (r) => await this.#h(r),
      [l.ButtonClick]: async (r) => await this.#l(r),
      [l.LinkClick]: async (r) => await this.#c(r),
      [l.Exit]: async (r) => await this.#u(r),
      [l.UrlRedirect]: async (r) => await this.#d(r),
      [l.SpinClick]: async (r) => await this.#a(r),
      [l.Any]: async (r) => await this.#r(r)
    }), this.#t = e, this.#e = i, this.#i = s, this.#n = n;
  }
  async #r(t) {
    const e = t.Payload?.Uid ?? t.Payload.FlowUid ?? t.Payload.ExperienceUid ?? null, i = t.Payload?.Details?.Properties?.ActivityUid ?? null, s = t.Payload?.Details?.Properties?.ActivityType ?? null;
    if (i !== null) {
      if (e === null) {
        u(new Error("Failed to find experience Uid for activity tracking step."), this.#s);
        return;
      }
      if (s === null) {
        u(new Error("Failed to find activity type for activity tracking step."), this.#s);
        return;
      }
      this.#o[e] = i, await this.#m(e, i, s);
    }
  }
  async #l(t) {
    const e = t.Payload.Uid;
    await this.#p(e, this.#o[e]);
  }
  async #a(t) {
    const e = t.Payload.Uid;
    await this.#w(e, this.#o[e]);
  }
  async #c(t) {
    const e = t.Payload.Uid;
    t.Payload.Url.startsWith("sms:") ? await this.#y(e, this.#o[e]) : await this.#f(e, this.#o[e]);
  }
  async #h(t) {
    const e = t.Payload?.Uid, i = t.Payload?.Channels !== void 0 ? { channels: t.Payload?.Channels } : void 0;
    await this.#m(e, this.#o[e], k.Submission, i);
  }
  async #u(t) {
    const e = ["closeX", "overlay"], i = t.Payload.Source;
    if (e.includes(i)) {
      const s = t.Payload.Uid;
      await this.#S(s, this.#o[s]);
    }
  }
  async #d(t) {
    const e = t.Payload.Uid;
    await this.#g(e, this.#o[e]);
  }
  #p = async (t, e) => await this.#m(t, e, k.PersistentButtonClick);
  #g = async (t, e) => await this.#m(t, e, k.UrlRedirect);
  #f = async (t, e) => await this.#m(t, e, k.LinkClick);
  #y = async (t, e) => await this.#m(t, e, k.TapToJoin);
  #S = async (t, e) => await this.#m(t, e, k.ExitClick);
  #w = async (t, e) => await this.#m(t, e, k.SpinnerClick);
  async #m(t, e, i, s = void 0) {
    const n = this.#C(t, e, i, s);
    try {
      await this.#n.Http.PostAsync(`${this.#e}/${this.#t}`, n);
    } catch (r) {
      u(r, this.#s);
    }
  }
  #C(t, e, i, s = void 0) {
    const n = this.#n.Cookie.GetCookie(`ltk-subscribed-email-${this.#t}`) || null;
    return {
      ActivityType: i,
      ExperienceUid: t,
      StepUid: e,
      GlobalSessionUid: this.#n.Cookie.GetCookie(this.#i),
      TrackingId: this.#t,
      Email: n,
      UserAgent: this.#n.Navigator.GetUserAgent(),
      Url: this.#n.Window.GetPageUrl(),
      DeviceType: this.#n.Device.GetType()?.toLowerCase(),
      Referrer: this.#n.Document.GetReferrer(),
      Properties: s
    };
  }
}
class ci extends m {
  #t = "PopupFlow.LinkClickService";
  constructor(t) {
    super(t, {
      [l.LinkClick]: async (e) => await this.#e(e)
    });
  }
  async #e(t) {
    const e = t.Payload.Uid;
    if (!e) {
      u(new Error("An error occurred on link click: Message sent without uid."), this.#t);
      return;
    }
    const i = t.Payload.Url;
    if (!i)
      return;
    const s = t.Payload.PopupUid;
    if (!s) {
      u(new Error("An error occurred on link click: Message sent without popup uid."), this.#t);
      return;
    }
    i.startsWith("sms:") && (this.PostMessage({ Type: l.CloseContent, Payload: s }), this.PostMessage({ Type: l.WaitComplete, Payload: { Uid: e } }));
  }
}
var f = /* @__PURE__ */ ((o) => (o[o.Url = 0] = "Url", o[o.Coupon = 1] = "Coupon", o[o.SubscribedChannel = 2] = "SubscribedChannel", o[o.DeviceType = 3] = "DeviceType", o[o.Referrer = 4] = "Referrer", o[o.Cart = 5] = "Cart", o[o.Product = 6] = "Product", o[o.ImpressionCount = 7] = "ImpressionCount", o[o.CountryCode = 8] = "CountryCode", o[o.CookieKeyValue = 9] = "CookieKeyValue", o[o.IPAddress = 10] = "IPAddress", o[o.SessionDepth = 11] = "SessionDepth", o[o.ListrakEmail = 12] = "ListrakEmail", o[o.CartTotal = 13] = "CartTotal", o[o.CartQuantity = 14] = "CartQuantity", o[o.CartSku = 15] = "CartSku", o[o.ExperienceHistory = 16] = "ExperienceHistory", o[o.Country = 17] = "Country", o[o.State = 18] = "State", o[o.Zip = 19] = "Zip", o[o.PreviousStep = 20] = "PreviousStep", o))(f || {}), w = /* @__PURE__ */ ((o) => (o[o.Is = 0] = "Is", o[o.IsNot = 1] = "IsNot", o[o.Contains = 2] = "Contains", o[o.DoesNotContain = 3] = "DoesNotContain", o[o.AtLeast = 4] = "AtLeast", o[o.LessThan = 5] = "LessThan", o[o.GreaterThan = 6] = "GreaterThan", o[o.Exists = 7] = "Exists", o[o.HasClicked = 8] = "HasClicked", o[o.HasNotClicked = 9] = "HasNotClicked", o[o.HasSubmitted = 10] = "HasSubmitted", o[o.HasNotSubmitted = 11] = "HasNotSubmitted", o))(w || {});
class ui {
  #t = "RuleGroup";
  #e = {};
  constructor(t) {
    this.#e = t;
  }
  Evaluate(t) {
    return this.#i(t, null);
  }
  EvaluateRuleGroup(t) {
    return this.#s(t, !0, null);
  }
  #i(t, e) {
    const i = t.TargetingRuleSet?.TargetingRules, s = i?.Show, n = i?.Hide;
    let r = !1, a = !0;
    if (s) {
      const c = e !== null ? [] : null;
      a = this.#s(s, !0, c), e !== null && e.push({
        Name: "Show",
        Passes: a,
        InnerEvals: c
      });
    }
    if (n) {
      const c = e !== null ? [] : null;
      r = this.#s(n, !1, c), e !== null && e.push({
        Name: "Hide",
        Passes: r,
        InnerEvals: c
      });
    }
    return r ? !1 : a;
  }
  #s(t, e, i) {
    const s = t.SubGroups;
    if (t.Enabled) {
      if (!s) throw new Error("Error evaluating targeting conditions: Rule group is enabled but sub groups are not defined");
      if (s.length === 0) return e;
      const n = t.Operator, r = i !== null ? [] : null;
      for (let a = 0; a < s.length; a++) {
        const c = this.#o(s[a], e, r);
        if (n === "AND" && c === !1)
          return i !== null && i.push({
            Name: n,
            Passes: !1,
            InnerEvals: r
          }), !1;
        if (n === "OR" && c === !0)
          return i !== null && i.push({
            Name: n,
            Passes: !0,
            InnerEvals: r
          }), !0;
      }
      if (n === "AND")
        return i !== null && i.push({
          Name: n,
          Passes: !0,
          InnerEvals: r
        }), !0;
      if (n === "OR")
        return i !== null && i.push({
          Name: n,
          Passes: !1,
          InnerEvals: r
        }), !1;
    }
    return e;
  }
  #o(t, e, i) {
    const s = t.Rules;
    if (!s) throw new Error("Error evaluating targeting conditions: Rule group is enabled but sub groups are not defined");
    if (s.length === 0) return e;
    const n = t.Operator;
    for (let r = 0; r < s.length; r++) {
      if (s[r].Category === null)
        throw new Error("Error evaluating targeting conditions: Rule category is not defined");
      const a = s[r].Category;
      if (!(a in this.#e))
        throw new Error("Error evaluating targeting conditions: No rule evaluator for " + a);
      const c = this.#e[a].Evaluate(s[r]);
      if (i !== null) {
        const h = s[r].Operator;
        i.push({
          Name: f[a] + (s[r].Key ? "(" + s[r].Key + ")" : "") + " " + w[h] + " " + s[r].Value,
          Passes: c
        });
      }
      if (n === "AND" && c === !1)
        return !1;
      if (n === "OR" && c === !0)
        return !0;
    }
    return n === "AND" ? !0 : n === "OR" ? !1 : e;
  }
  DebugEvaluate(t) {
    let e = !1;
    const i = [];
    return e = this.#i(t, i), {
      Name: this.#t,
      Passes: e,
      InnerEvals: i
    };
  }
  DebugEvaluateRuleGroup(t) {
    let e = !1;
    const i = [];
    return e = this.#s(t, !0, i), {
      Name: this.#t,
      Passes: e,
      InnerEvals: i
    };
  }
}
function C() {
  return /* @__PURE__ */ new Map([
    [w.Is, ut],
    [w.IsNot, hi],
    [w.Contains, ht],
    [w.DoesNotContain, di],
    [w.AtLeast, () => !0],
    [w.LessThan, pi],
    [w.GreaterThan, gi],
    [w.Exists, mi]
  ]);
}
function ut(o, t) {
  return Array.isArray(t) ? Array.isArray(o) ? o.some((e) => t.includes(e)) : t.includes(o) : Array.isArray(o) ? o.includes(t) : o === t;
}
function hi(o, t) {
  return !ut(o, t);
}
function ht(o, t) {
  return Array.isArray(t) ? Array.isArray(o) ? o.some(
    (e) => t.some((i) => typeof i == "number" || typeof e == "number" ? i === e : String(i).includes(String(e)))
  ) : t.some((e) => typeof o == "number" || typeof e == "number" ? o === e : String(e).includes(String(o))) : Array.isArray(o) ? o.some((e) => typeof e == "number" || typeof t == "number" ? e === t : String(t).includes(String(e))) : typeof o == "number" || typeof t == "number" ? o === t : String(t).includes(String(o));
}
function di(o, t) {
  return !ht(o, t);
}
function pi(o, t) {
  return o < t;
}
function gi(o, t) {
  return o > t;
}
function mi(o) {
  return o != null && o !== "";
}
var _ = /* @__PURE__ */ ((o) => (o.Email = "Email", o.Sms = "SMS", o))(_ || {});
class fi {
  #t = "ListrakSource";
  #e = C();
  #i;
  constructor(t) {
    this.#i = t;
  }
  Evaluate(t) {
    if (t.Operator === null)
      throw new Error("Error evaluating Listrak Source rule: Rule operator is not defined");
    const e = this.#e.get(t.Operator);
    if (e) {
      let i = this.#i.Session.GetIsFromListrak();
      return i === "E" ? i = _.Email : i === "S" && (i = _.Sms), e(t.Value, i);
    } else
      throw new Error("Error evaluating Listrak Source rule: Test for operator not found");
  }
  DebugEvaluate(t) {
    return {
      Name: this.#t,
      Passes: this.Evaluate(t)
    };
  }
}
class yi {
  #t = "Url";
  #e = C();
  #i;
  constructor(t) {
    this.#i = t;
  }
  Evaluate(t) {
    if (t.Operator === null)
      throw new Error("Error evaluating Url rule: Rule operator is not defined");
    const e = this.#e.get(t.Operator);
    if (e && t.Value !== null)
      return typeof t.Value == "number" ? e(t.Value, this.#i.Window.GetPageUrl().toLowerCase()) : Array.isArray(t.Value) ? e(t.Value.map((i) => i.toLowerCase()), this.#i.Window.GetPageUrl().toLowerCase()) : e(t.Value.toLowerCase(), this.#i.Window.GetPageUrl().toLowerCase());
    throw new Error("Error evaluating Url rule: Test for operator not found");
  }
  DebugEvaluate(t) {
    return {
      Name: this.#t,
      Passes: this.Evaluate(t)
    };
  }
}
var V = /* @__PURE__ */ ((o) => (o.Email = "Email", o.Sms = "SMS", o))(V || {});
class wi {
  #t = "Subscription";
  #e;
  #i;
  #s;
  constructor(t, e, i) {
    this.#e = e, this.#i = i, this.#s = t;
  }
  Evaluate(t) {
    if (t.Operator === null)
      throw new Error("Error evaluating Subscription rule: Rule operator is not defined");
    const e = this.#e.get(t.Operator);
    if (!e)
      throw new Error("Error evaluating Subscription rule: Test for operator not found");
    return e(t.Value, this.#o());
  }
  DebugEvaluate(t) {
    return {
      Name: this.#t,
      Passes: this.Evaluate(t)
    };
  }
  #o() {
    const t = JSON.parse(this.#s.Cookie.GetCookie(`ltk-subscribed-channel-${this.#i}`) || "{}"), e = this.#s.Cookie.GetCookie(`subscription_status-${this.#i}`);
    t.Email = t.Email || !!e;
    const i = [];
    return t?.Email && i.push(V.Email), t?.Sms && i.push(V.Sms), i;
  }
}
var z = /* @__PURE__ */ ((o) => (o.Paid = "Paid", o.Organic = "Organic", o))(z || {});
const Si = [
  {
    Domains: [/www\.google\.com/],
    QueryStrings: [/[?&]gclid=/, /[?&]utm_source=google(&|$)/]
  }
];
class Ci {
  #t = "Referrer";
  #e;
  #i;
  constructor(t, e) {
    this.#e = e, this.#i = t;
  }
  Evaluate(t) {
    if (t.Operator === null)
      throw new Error("Error evaluating Referrer rule: Rule operator is not defined");
    const e = this.#e.get(t.Operator);
    if (!e)
      throw new Error("Error evaluating Referrer rule: Test for operator not found");
    return e(t.Value, this.#s());
  }
  DebugEvaluate(t) {
    return {
      Name: this.#t,
      Passes: this.Evaluate(t)
    };
  }
  #s() {
    const t = [];
    return this.#o() ? t.push(z.Paid) : t.push(z.Organic), t;
  }
  #o() {
    const t = this.#i.Document.GetReferrer();
    return Si.some((e) => this.#n(t, e));
  }
  #n(t, e) {
    return !!(e.Domains.some((i) => i.test(t.toLowerCase())) || e.QueryStrings.some((i) => this.#i.QueryString.RegexMatchQueryString(i)));
  }
}
class bi {
  #t = "DeviceType";
  #e = C();
  #i;
  constructor(t) {
    this.#i = t;
  }
  Evaluate(t) {
    if (t.Operator === null)
      throw new Error("Error evaluating Device Type rule: Rule operator is not defined");
    const e = this.#e.get(t.Operator);
    if (e)
      return e(t.Value, this.#i.Device.GetType());
    throw new Error("Error evaluating Device Type rule: Test for operator not found");
  }
  DebugEvaluate(t) {
    return {
      Name: this.#t,
      Passes: this.Evaluate(t)
    };
  }
}
const tt = "ltk-flow-tags-";
class vi {
  GetTags(t) {
    const e = window.sessionStorage.getItem(tt + t);
    return e ? JSON.parse(e) : {};
  }
  SetTag(t, e, i) {
    const s = this.GetTags(t);
    s[e] = i, this.#t(t, s);
  }
  SetTags(t, e) {
    const i = this.GetTags(t);
    for (const s in e)
      i[s] = e[s];
    this.#t(t, i);
  }
  #t(t, e) {
    window.sessionStorage.setItem(tt + t, JSON.stringify(e));
  }
}
class ki {
  #t;
  constructor(t) {
    this.#t = t;
  }
  async GetDataAsync(t) {
    const e = await this.#t.Assign(t);
    return {
      Code: e.couponCode,
      Expiration: new Date(e.couponExpiration),
      Uid: t
    };
  }
}
class Ei extends m {
  #t;
  #e;
  #i = "PopupFlow.CouponService";
  constructor(t, e, i) {
    super(t, {
      [l.AssignCoupon]: async (s) => await this.#s(s)
    }), this.#t = e, this.#e = i;
  }
  async #s(t) {
    const e = t.Payload?.Details?.Properties?.CouponPoolUid, i = t.Payload?.FlowUid;
    let s = "";
    if (e)
      try {
        s = (await this.#t.GetDataAsync(e)).Code;
      } catch (r) {
        u(r, this.#i);
      }
    else
      u(new Error(`Coupon Pool UID for flow ${t.Payload.PopupFlowUid} could not be found`), this.#i);
    let n = {};
    n = this.#o(n, t, "CouponCodeTagName", s, !0), n = this.#o(n, t, "CouponTitleTagName", "CouponTitle"), n = this.#o(n, t, "CouponDescriptionTagName", "CouponDescription"), n = this.#o(n, t, "CouponExpirationTagName", "CouponExpiration"), n = this.#o(n, t, "CouponDisclaimerTagName", "CouponDisclaimer"), this.#e.SetTags(i, n), this.PostMessage({ Type: l.WaitComplete, Payload: { Uid: i } });
  }
  #o(t, e, i, s, n) {
    if (!e.Payload?.Details?.Properties || !(i in e.Payload?.Details?.Properties) || !n && !(s in e.Payload?.Details?.Properties))
      return t;
    let r = e.Payload?.Details?.Properties[i] ?? "", a = s ?? "";
    return !r || (n || (a = e.Payload?.Details?.Properties[s]), !a) || (r = "{{Experience:" + r.trim() + "}}", a = a.trim(), t[r] = a), t;
  }
}
class dt {
  #t;
  constructor(t) {
    this.#t = t;
  }
  get #e() {
    return `offers-${this.#t}`;
  }
  get #i() {
    const t = window.localStorage.getItem(this.#e);
    if (t === null) return [];
    const e = JSON.parse(t);
    return this.#s(e.map(({ Code: i, Expiration: s, Uid: n }) => ({
      Code: i,
      Expiration: new Date(s),
      Uid: n
    })));
  }
  get HasOffers() {
    return this.#i.length > 0;
  }
  Cache(t) {
    const e = this.#i;
    e.push(t);
    const i = e.map(({ Code: s, Expiration: n, Uid: r }) => ({
      Code: s,
      Expiration: n.toISOString(),
      Uid: r
    }));
    window.localStorage.setItem(
      this.#e,
      JSON.stringify(i)
    );
  }
  GetCachedOffers() {
    return this.#i;
  }
  Clear() {
    window.localStorage.removeItem(this.#e);
  }
  Dispense(t) {
    return this.#i.length === 0 ? null : t !== void 0 ? this.#i.find((e) => e.Uid === t) ?? null : this.#i[this.#i.length - 1];
  }
  #s(t) {
    const e = (/* @__PURE__ */ new Date()).getTime();
    return t.filter((i) => i.Expiration.getTime() > e);
  }
}
class Pi {
  #t;
  #e;
  #i;
  #s = "CouponRequest.Dispense";
  #o;
  constructor(t, e) {
    this.#e = e.DefaultBaseUrl, this.#o = e.MerchantTrackingId, this.#i = new dt(e.MerchantTrackingId), this.#t = t;
  }
  async Assign(t) {
    try {
      const e = await (await this.#t.Http.PutAsync(`${this.#e}/coupon`, {
        Uid: t,
        TrackingId: this.#o
      })).json(), i = this.#n(e.couponExpiration);
      return this.#i.Cache({
        Code: e.couponCode ?? "",
        Expiration: new Date(i),
        Uid: t
      }), {
        couponCode: e.couponCode,
        couponExpiration: i
      };
    } catch {
      this.#s;
      const e = /* @__PURE__ */ new Date();
      return e.setDate(e.getDate() - 30), {
        couponCode: "",
        couponExpiration: e.toISOString()
      };
    }
  }
  #n(t) {
    const e = /* @__PURE__ */ new Date();
    if (e.setDate(e.getDate() + 30), t === null) return e.toISOString();
    const i = typeof t == "string" ? Date.parse(t) : Date.parse(t.toString());
    return Number.isNaN(i) ? e.toISOString() : new Date(i).toISOString();
  }
}
class xi {
  #t = "Coupon";
  #e = C();
  #i;
  constructor(t) {
    this.#i = t;
  }
  Evaluate(t) {
    if (t.Operator === null)
      throw new Error("Error evaluating Coupon rule: Rule operator is not defined");
    const e = this.#e.get(t.Operator);
    if (e) {
      const i = this.#i.GetCachedOffers().map((n) => n.Uid?.toLowerCase()), s = this.SanitizeRuleValues(t.Value);
      return s.includes("any") ? this.#i.HasOffers : e(s, i);
    } else
      throw new Error("Error evaluating Coupon rule: Test for operator not found");
  }
  DebugEvaluate(t) {
    return {
      Name: this.#t,
      Passes: this.Evaluate(t)
    };
  }
  SanitizeRuleValues(t) {
    if (Array.isArray(t))
      return t.map((e) => e.toLowerCase());
    throw new Error("Error evaluating Coupon rule: Coupon Rule Values not in array format");
  }
}
class Ti {
  #t = "Cookie";
  #e = C();
  #i;
  constructor(t) {
    this.#i = t;
  }
  Evaluate(t) {
    if (t.Operator === null)
      throw new Error("Error evaluating Cookie rule: Rule operator is not defined");
    if (t.Key === null)
      throw new Error("Error evaluating Cookie rule: Rule key is not defined");
    if (typeof t.Key == "number")
      throw new Error("Error evaluating Cookie rule: Rule key is numerical");
    if (Array.isArray(t.Key))
      throw new Error("Error evaluating Cookie rule: Rule key is an array");
    const e = this.#e.get(t.Operator);
    if (e) {
      if (t.Operator === w.Exists)
        return e(this.#i.Cookie.GetCookie(t.Key), null);
      if (t.Value !== null)
        return e(t.Value, this.#i.Cookie.GetCookie(t.Key));
      throw new Error("Error evaluating Cookie rule: Test for operator not found");
    } else
      throw new Error("Error evaluating Cookie rule: Rule operator not found");
  }
  DebugEvaluate(t) {
    return {
      Name: this.#t,
      Passes: this.Evaluate(t)
    };
  }
}
class Ii extends m {
  #t = "PopupFlow.RandomSplitService";
  constructor(t) {
    super(t, {
      [l.RandomSplit]: async (e) => await this.#e(e)
    });
  }
  async #e(t) {
    if (!t.Payload.Details.Properties.BranchDetailsList) {
      u(new Error("Error retrieving branch details: branch details list is null"), this.#t);
      return;
    }
    const e = t.Payload.Details.Properties.BranchDetailsList;
    if (e.length === 0) {
      u(new Error("Error retrieving branch details: branch details list is empty"), this.#t);
      return;
    }
    const i = Math.random();
    let s = "", n = 0;
    for (let r = 0; r < e.length; r++) {
      const a = e[r];
      if (n += a.Propensity ?? 0, i <= n) {
        s = a.StartingGuid;
        break;
      }
    }
    this.PostMessage({ Type: l.GoToStep, Payload: { Uid: t.Payload.FlowUid, StepUid: s } });
  }
}
class Di extends m {
  #t = "PopupFlow.ConditionSplitService";
  #e;
  #i;
  #s;
  constructor(t, e, i, s = null) {
    super(t, {
      [l.ConditionSplit]: async (n) => await this.#o(n)
    }), this.#e = e, this.#i = i, this.#s = s;
  }
  async #o(t) {
    if (!t.Payload.Details.Properties.BranchDetailsList) {
      u(new Error("Error retrieving branch details: branch details list is null"), this.#t);
      return;
    }
    const e = t.Payload.Details.Properties.BranchDetailsList;
    if (e.length === 0) {
      u(new Error("Error retrieving branch details: branch details list is empty"), this.#t);
      return;
    }
    this.#s && this.#s.SetFlowContext(t.Payload.FlowUid);
    let i = "";
    const s = this.#i.IsDebugEnabled(l.ConditionSplit);
    for (let n = 0; n < e.length; n++) {
      const r = e[n], a = r.FilterCriteria;
      if (!a) {
        i = r.StartingGuid;
        break;
      }
      if (!s && this.#e.EvaluateRuleGroup(a)) {
        i = r.StartingGuid;
        break;
      } else if (s) {
        const c = this.#e.DebugEvaluateRuleGroup(a);
        if (console.log("Condition Split Rule Evaluation:", r.StartingGuid, c), c.Passes) {
          i = r.StartingGuid;
          break;
        }
      }
    }
    this.PostMessage({ Type: l.GoToStep, Payload: { Uid: t.Payload.FlowUid, StepUid: i } });
  }
}
var b = /* @__PURE__ */ ((o) => (o.Link = "link", o.Action = "action", o.FormSubmit = "formSubmit", o.TTJ = "ttj", o))(b || {});
class Ui extends m {
  #t = {};
  #e = {};
  constructor(t) {
    super(t, {
      [l.Any]: async (e) => this.#i(e),
      [l.FormSubmission]: async (e) => this.#s(e),
      [l.LinkClick]: async (e) => this.#o(e),
      [l.SpinClick]: async (e) => this.#n(e)
    });
  }
  #i(t) {
    const e = t.Payload?.Uid ?? t.Payload?.FlowUid ?? t.Payload?.ExperienceUid ?? null, i = t.Payload?.Details?.Properties?.ActivityUid ?? null, s = t.Payload?.Details?.Properties?.ActivityType ?? null;
    e !== null && i !== null && s === "content-impression" && (this.#t[e] = i, this.#r(e, i));
  }
  RecordSubmit(t, e, i) {
    if (!t) return;
    const s = i ?? this.#t[t];
    if (!s) return;
    const n = this.#r(t, s);
    if (n.interactionTypes.add(b.FormSubmit), e && typeof e == "object")
      for (const r in e)
        n.formFields[r] = e[r];
  }
  #s(t) {
    this.RecordSubmit(t.Payload?.Uid, t.Payload?.FormFields, t.Payload?.StepUid);
  }
  RecordClick(t, e, i) {
    if (!t) return;
    const s = i ?? this.#t[t];
    if (!s) return;
    const n = this.#r(t, s);
    e && e.startsWith("sms:") ? n.interactionTypes.add(b.TTJ) : n.interactionTypes.add(b.Link);
  }
  #o(t) {
    this.RecordClick(t.Payload?.Uid, t.Payload?.Url, t.Payload?.StepUid);
  }
  #n(t) {
    const e = t.Payload?.Uid;
    if (!e) return;
    const i = t.Payload?.StepUid ?? this.#t[e];
    i && this.#r(e, i).interactionTypes.add(b.Action);
  }
  #r(t, e) {
    return this.#e[t] || (this.#e[t] = {}), this.#e[t][e] || (this.#e[t][e] = { interactionTypes: /* @__PURE__ */ new Set(), formFields: {} }), this.#e[t][e];
  }
  HasClicked(t, e) {
    const i = this.#e[t]?.[e]?.interactionTypes;
    return i ? i.has(b.Link) || i.has(b.Action) : !1;
  }
  HasSubmitted(t, e) {
    const i = this.#e[t]?.[e]?.interactionTypes;
    return i ? i.has(b.FormSubmit) || i.has(b.TTJ) : !1;
  }
  GetFormFieldValue(t, e, i) {
    const s = this.#e[t]?.[e]?.formFields[i];
    return s !== void 0 ? s : null;
  }
}
class Ri {
  #t = "PreviousStep";
  #e;
  #i = "";
  constructor(t) {
    this.#e = t;
  }
  SetFlowContext(t) {
    this.#i = t;
  }
  Evaluate(t) {
    if (t.Category !== f.PreviousStep) return !1;
    const e = t.Key;
    return !e || !this.#s(e, t.Operator) ? !1 : t.Value && Array.isArray(t.Value) ? this.#o(e, t.Value) : !0;
  }
  #s(t, e) {
    switch (e) {
      case w.HasClicked:
        return this.#e.HasClicked(this.#i, t);
      case w.HasNotClicked:
        return !this.#e.HasClicked(this.#i, t);
      case w.HasSubmitted:
        return this.#e.HasSubmitted(this.#i, t);
      case w.HasNotSubmitted:
        return !this.#e.HasSubmitted(this.#i, t);
      default:
        return !1;
    }
  }
  #o(t, e) {
    let i = e[0];
    const s = e[1], n = e[2] ?? null, r = i.match(/^\d+:(.+)$/);
    r && (i = r[1]);
    const a = this.#e.GetFormFieldValue(this.#i, t, i);
    switch (s) {
      case "present":
        return a !== null && a !== "";
      case "equals":
        return a !== null && String(a).toLowerCase() === String(n).toLowerCase();
      case "notEquals":
        return a === null || String(a).toLowerCase() !== String(n).toLowerCase();
      case "greaterThan":
        return Number(a) > Number(n);
      case "lessThan":
        return Number(a) < Number(n);
      case "contains":
        return a !== null && String(a).toLowerCase().includes(String(n).toLowerCase());
      case "doesNotContain":
        return a === null || !String(a).toLowerCase().includes(String(n).toLowerCase());
      case "before":
        return a !== null && n !== null && Date.parse(a) < Date.parse(n);
      case "after":
        return a !== null && n !== null && Date.parse(a) > Date.parse(n);
      case "isTrue":
        return a !== null && a !== "" && a !== "0" && a?.toLowerCase() !== "false" && a?.toLowerCase() !== "off";
      case "isFalse":
        return a === null || a === "" || a === "0" || a?.toLowerCase() === "false" || a?.toLowerCase() === "off";
      default:
        return !1;
    }
  }
  DebugEvaluate(t) {
    return {
      Name: this.#t,
      Passes: this.Evaluate(t)
    };
  }
}
var U = /* @__PURE__ */ ((o) => (o.Seen = "Seen", o.Clicked = "Clicked", o.Submitted = "Submitted", o))(U || {});
class Ai extends m {
  #t = 14;
  #e = "PopupFlow.ExperienceHistory";
  #i = "ltk-exp-history-";
  constructor(t) {
    super(t, {
      [l.ContentRender]: async (e) => await this.#s(e),
      [l.LinkClick]: async (e) => await this.#o(e),
      [l.ButtonClick]: async (e) => await this.#n(e),
      [l.FormSubmission]: async (e) => await this.#r(e)
    });
  }
  GetExperienceHistory(t) {
    const e = window.localStorage.getItem(this.#i + t), i = e ? JSON.parse(e) : {
      Expiry: null,
      Events: []
    };
    return i.Expiry != null && new Date(i.Expiry) <= /* @__PURE__ */ new Date() ? (window.localStorage.removeItem(this.#i + t), {
      Expiry: null,
      Events: []
    }) : {
      Expiry: i.Expiry,
      Events: i.Events.filter((s) => /* @__PURE__ */ new Date() < new Date(s.Expiry))
    };
  }
  SetExperienceHistory(t, e) {
    const i = /* @__PURE__ */ new Date(), s = /* @__PURE__ */ new Date();
    s.setDate(s.getDate() + this.#t);
    const n = this.GetExperienceHistory(t);
    n.Expiry = s.toISOString(), n.Events.push({
      Type: e,
      Date: i.toISOString(),
      Expiry: s.toISOString()
    }), window.localStorage.setItem(this.#i + t, JSON.stringify(n));
  }
  async #s(t) {
    const e = t.Payload?.FlowUid;
    if (!e) {
      u(new Error("Failed to find experience Uid for content render event."), this.#e);
      return;
    }
    this.SetExperienceHistory(e, U.Seen);
  }
  async #o(t) {
    const e = t.Payload?.Uid;
    if (!e) {
      u(new Error("Failed to find experience Uid for link click event."), this.#e);
      return;
    }
    this.SetExperienceHistory(e, U.Clicked);
  }
  async #n(t) {
    const e = t.Payload?.Uid;
    if (!e) {
      u(new Error("Failed to find experience Uid for button click event."), this.#e);
      return;
    }
    this.SetExperienceHistory(e, U.Clicked);
  }
  async #r(t) {
    const e = t.Payload?.Uid;
    if (!e) {
      u(new Error("Failed to find experience Uid for form submission event."), this.#e);
      return;
    }
    this.SetExperienceHistory(e, U.Submitted);
  }
}
class $i {
  #t;
  constructor(t) {
    this.#i(), this.#t = "ltk_cart_data_" + t;
  }
  GetCartTotal() {
    const t = this.#e();
    return t ? t.TotalPrice : null;
  }
  GetCartQuantity() {
    const t = this.#e();
    return t ? t.TotalQuantity : null;
  }
  GetCartSkus() {
    const t = this.#e();
    return t ? t.Skus : null;
  }
  #e() {
    try {
      const t = window.localStorage.getItem(this.#t);
      return t ? JSON.parse(t) : null;
    } catch {
      return null;
    }
  }
  #i() {
    document.addEventListener("ltkAddToCart", this.#s.bind(this)), document.addEventListener("ltkClearCart", this.#o.bind(this));
  }
  #s = (t) => {
    const e = t;
    if (e.detail && e.detail.items) {
      const { totalPrice: i, totalQuantity: s, skus: n } = this.#n(e.detail.items);
      this.#r(s, i, n);
    }
  };
  #o = () => {
    this.#l();
  };
  #n(t) {
    return t.reduce(
      (e, i) => ({
        totalQuantity: e.totalQuantity + i.Quantity,
        totalPrice: e.totalPrice + i.Price * i.Quantity,
        skus: [...e.skus, i.Sku]
      }),
      { totalQuantity: 0, totalPrice: 0, skus: [] }
    );
  }
  #r(t, e, i = []) {
    try {
      const s = {
        TotalQuantity: t,
        TotalPrice: e,
        Skus: i
      };
      window.localStorage.setItem(this.#t, JSON.stringify(s));
    } catch {
    }
  }
  #l() {
    window.localStorage.removeItem(this.#t);
  }
}
class Fi {
  #t = "CartTotal";
  #e = C();
  #i;
  constructor(t) {
    this.#i = t;
  }
  Evaluate(t) {
    if (t.Operator === null)
      throw new Error("Error evaluating CartTotal rule: Rule operator is not defined");
    const e = this.#e.get(t.Operator);
    if (e) {
      const i = this.#s(t.Value), s = this.#i.GetCartTotal();
      if (s == null)
        throw new E("Cart data not available: Cannot evaluate CartTotal rule until cart data is loaded");
      return e(s, i);
    } else
      throw new Error("Error evaluating CartTotal rule: Test for operator not found");
  }
  DebugEvaluate(t) {
    return {
      Name: this.#t,
      Passes: this.Evaluate(t)
    };
  }
  #s(t) {
    if (typeof t == "number")
      return [t];
    if (typeof t == "string")
      return [parseFloat(t)];
    throw new Error("Error evaluating CartTotal rule: Cart Total Rule Values not in valid format");
  }
}
class Mi {
  #t = "CartQuantity";
  #e = C();
  #i;
  constructor(t) {
    this.#i = t;
  }
  Evaluate(t) {
    if (t.Operator === null)
      throw new Error("Error evaluating CartQuantity rule: Rule operator is not defined");
    const e = this.#e.get(t.Operator);
    if (e) {
      const i = this.#s(t.Value), s = this.#i.GetCartQuantity();
      if (s == null)
        throw new E("Cart data not available: Cannot evaluate CartQuantity rule until cart data is loaded");
      return e(s, i);
    } else
      throw new Error("Error evaluating CartQuantity rule: Test for operator not found");
  }
  DebugEvaluate(t) {
    return {
      Name: this.#t,
      Passes: this.Evaluate(t)
    };
  }
  #s(t) {
    if (typeof t == "number")
      return t;
    if (typeof t == "string")
      return parseInt(t, 10);
    throw new Error("Error evaluating CartQuantity rule: Cart Quantity Rule Values not in valid format");
  }
}
class Li {
  #t = "CartSku";
  #e = C();
  #i;
  constructor(t) {
    this.#i = t;
  }
  Evaluate(t) {
    if (t.Operator === null)
      throw new Error("Error evaluating CartSku rule: Rule operator is not defined");
    const e = this.#e.get(t.Operator);
    if (e) {
      const i = this.#s(t.Value), s = this.#i.GetCartSkus();
      if (s == null)
        throw new E("Cart data not available: Cannot evaluate CartSku rule until cart data is loaded");
      return e(i, s);
    } else
      throw new Error("Error evaluating CartSku rule: Test for operator not found");
  }
  DebugEvaluate(t) {
    return {
      Name: this.#t,
      Passes: this.Evaluate(t)
    };
  }
  #s(t) {
    if (typeof t == "string")
      return [t];
    if (Array.isArray(t))
      return t.map((e) => e.toString());
    throw new Error("Error evaluating CartSku rule: Cart SKU Rule Values not in valid format");
  }
}
class Bi {
  #t = "ExperienceHistory";
  #e = C();
  #i;
  constructor(t) {
    this.#i = t;
  }
  Evaluate(t) {
    if (t.Operator === null)
      throw new Error("Error evaluating ExperienceHistory rule: Rule operator is not defined");
    if (t.Key === null)
      throw new Error("Error evaluating ExperienceHistory rule: Rule key is not defined");
    if (typeof t.Key == "number")
      throw new Error("Error evaluating ExperienceHistory rule: Rule key is numerical");
    if (t.Value === null)
      throw new Error("Error evaluating ExperienceHistory rule: Rule value is not defined");
    const e = this.#e.get(t.Operator);
    if (!e)
      throw new Error("Error evaluating ExperienceHistory rule: Rule operator not found");
    const i = this.#o(t.Key);
    for (const s in i) {
      const n = i[s];
      if (e(t.Value, n))
        return !0;
    }
    return !1;
  }
  DebugEvaluate(t) {
    return {
      Name: this.#t,
      Passes: this.Evaluate(t)
    };
  }
  #s(t) {
    const e = this.#i.GetExperienceHistory(t);
    return [...new Set(e.Events.map((i) => i.Type))];
  }
  #o(t) {
    const e = {};
    if (!Array.isArray(t))
      e[t] = this.#s(t);
    else
      for (const i of t)
        e[i] = this.#s(i);
    return e;
  }
}
const pt = "default";
function B(o) {
  if (!o?.SubGroups) return !1;
  for (const t of o.SubGroups)
    if (t.Rules) {
      for (const e of t.Rules)
        if (e.Action && e.Action !== pt)
          return !0;
    }
  return !1;
}
function et(o) {
  const t = [];
  if (!o?.SubGroups) return t;
  for (const e of o.SubGroups)
    if (e.Rules)
      for (const i of e.Rules)
        i.Action && i.Action !== pt && i.RuleId && t.push(i.RuleId);
  return t;
}
const R = "ltk-backend-rule-matches";
class Oi {
  #t;
  #e;
  #i;
  constructor(t, e, i) {
    this.#t = t, this.#e = e, this.#i = i;
  }
  async PrefetchAsync(t) {
    if (!this.HasBackendRules(t))
      return;
    const e = window.sessionStorage.getItem(R);
    if (!(e && !this.IsCacheStale(e, t))) {
      e && window.sessionStorage.removeItem(R);
      try {
        const i = `${this.#t}/targeting?trackingId=${this.#e}`, s = await this.#i.Http.GetAsync(i);
        s.ruleMatches && window.sessionStorage.setItem(R, JSON.stringify(s.ruleMatches));
      } catch {
        throw new E("Backend rule match data is not available");
      }
    }
  }
  IsCacheStale(t, e) {
    let i;
    try {
      i = JSON.parse(t);
    } catch {
      return !0;
    }
    for (const s of e) {
      const n = s.TargetingRuleSet?.TargetingRules, r = et(n?.Show), a = et(n?.Hide);
      for (const c of r)
        if (!(c in i)) return !0;
      for (const c of a)
        if (!(c in i)) return !0;
    }
    return !1;
  }
  HasBackendRules(t) {
    for (const e of t) {
      const i = e.TargetingRuleSet?.TargetingRules;
      if (B(i?.Show) || B(i?.Hide))
        return !0;
    }
    return !1;
  }
}
class Gi {
  #t = "BackendRule";
  Evaluate(t) {
    if (!t.RuleId)
      return !1;
    const e = window.sessionStorage.getItem(R);
    return e ? JSON.parse(e)[t.RuleId] === !0 : !1;
  }
  DebugEvaluate(t) {
    return {
      Name: this.#t,
      Passes: this.Evaluate(t)
    };
  }
}
class Ni {
  #t = "BackendDataAvailability";
  Evaluate(t) {
    return this.#e(t) ? window.sessionStorage.getItem(R) !== null : !0;
  }
  DebugEvaluate(t) {
    return {
      Name: this.#t,
      Passes: this.Evaluate(t)
    };
  }
  #e(t) {
    const e = t.TargetingRuleSet?.TargetingRules;
    return B(e?.Show) || B(e?.Hide);
  }
}
class Hi {
  #t = {};
  #e = 0;
  Subscribe(t) {
    for (const e in t) {
      const i = t[e], s = {
        Id: this.#e,
        Route: i
      };
      this.#t[e] || (this.#t[e] = []), this.#t[e].push(s);
    }
    return this.#e++, this.#e - 1;
  }
  Unsubscribe(t) {
    for (const e in this.#t)
      this.#t[e] = this.#t[e].filter((i) => i.Id != t);
  }
  async PostMessage(t, e) {
    if (await this.#i(l.Any, y.Any, t, e), t.Type) {
      const i = t.Payload?.Details?.Type;
      i ? await this.#i(t.Type, i, t, e) : await this.#i(t.Type, y.Any, t, e);
    }
  }
  async #i(t, e, i, s) {
    const n = this.#t[t];
    if (n)
      for (const r of n) {
        if (r.Id === s)
          continue;
        const a = r.Route;
        typeof a == "function" ? await a(i) : (await a[e]?.(i), e !== y.Any && await a[y.Any]?.(i));
      }
  }
}
class Wi {
  static Create(t, e, i, s, n) {
    Fe(t.DefaultBaseUrl, t.MerchantTrackingId);
    const r = new Hi(), a = new He(t.WebContentBaseUrl, t.MerchantTrackingId, i), c = new Ne(t.WebContentBaseUrl, i), h = new Oe(t.WebContentBaseUrl, i, s), d = new Pi(i, { MerchantTrackingId: t.MerchantTrackingId, DefaultBaseUrl: t.CouponBaseUrl }), p = new dt(t.MerchantTrackingId), g = new ki(d), v = new vi(), P = new Ke(r), $ = new Ui(r), mt = new ni(r, n, $), G = new $i(t.MerchantTrackingId), ft = new Ai(r), yt = new Oi(t.TargetingBaseUrl, t.MerchantTrackingId, i);
    new We(r, c), new ze(r), new _e(r, h), new Ve(r, h), new je(r, e, mt, s, i, $), new Ii(r), new Xe(r, v), new Ye(r, i), new ti(r, i), new ei(r, i), new ri(r, ai, i, s), new li(r, t.MerchantTrackingId, t.ActivityTrackingBaseUrl, t.SessionCookieName, i), new Ei(r, g, v), new ci(r);
    const I = new ii();
    I.AddEvaluator(new si(i)), I.AddEvaluator(new oi(i)), I.AddEvaluator(new Ni());
    const J = new Ri($), q = C(), F = new Gi(), Q = new ui({
      [f.Url]: new yi(i),
      [f.DeviceType]: new bi(i),
      [f.ListrakEmail]: new fi(i),
      [f.SubscribedChannel]: new wi(i, q, t.MerchantTrackingId),
      [f.Coupon]: new xi(p),
      [f.Referrer]: new Ci(i, q),
      [f.CartTotal]: new Fi(G),
      [f.CartQuantity]: new Mi(G),
      [f.CartSku]: new Li(G),
      [f.CookieKeyValue]: new Ti(i),
      [f.ExperienceHistory]: new Bi(ft),
      [f.Country]: F,
      [f.State]: F,
      [f.Zip]: F,
      [f.IPAddress]: F,
      [f.PreviousStep]: J
    });
    return I.AddEvaluator(Q), new Di(r, Q, P, J), new Be(i, a, r, P, I, h, c, yt);
  }
}
class _i {
  #t;
  constructor(t) {
    this.#t = t;
  }
  Init() {
    this.#t.Init();
  }
  EnableDebug() {
    this.#t.EnableDebug();
  }
  SetCaching(t) {
    this.#t.SetCaching(t);
  }
  async ManualTrigger(t) {
    await this.#t.ManualTrigger(t, !1);
  }
  async ManualEvaluate(t) {
    await this.#t.ManualTrigger(t, !0);
  }
  NextStep(t, e) {
    this.#t.NextStep(t, e);
  }
  ClosePopup(t, e) {
    this.#t.ClosePopup(t, e);
  }
}
class Vi {
  static Create(t) {
    const e = {}, i = new Proxy(e, {
      // eslint-disable-next-line @typescript-eslint/naming-convention
      get(s, n) {
        return s[n];
      },
      // eslint-disable-next-line @typescript-eslint/naming-convention
      set(s, n, r) {
        return n === "reload" ? (s.OldReload = r, !0) : n === "OscReload" ? (s.reload = r, !0) : (s[n] = r, !0);
      }
    });
    return i.OscReload = () => {
      i.OldReload?.(), t.Reload();
    }, i;
  }
}
class gt {
  static Create(t, e) {
    e = e || document, ce(t.DefaultBaseUrl, t.MerchantTrackingId);
    const i = {
      DefaultBaseUrl: t.DefaultBaseUrl,
      MerchantTrackingId: t.MerchantTrackingId,
      CouponBaseUrl: t.CouponBaseUrl
    }, s = De.Create(i, e), n = new ge(x), r = new me(x, t.MerchantTrackingId), a = new fe(x, t.MerchantTrackingId), c = new Ce(t, n, r, a, x, e), h = Wi.Create(t, s, x, e, c), d = new pe(t.Features, t.MerchantTrackingId, x, h, s, c), p = new _i(d.PopupFlow), g = Vi.Create(d), v = new ue(d, t.Features.EnablePopupFlow ? p : void 0, g), P = new he(d);
    return {
      Ltk: v,
      LtkUtil: P,
      Proxies: {
        Ltk: {
          OnsiteContent: g
        },
        LtkUtil: {}
      }
    };
  }
}
window !== void 0 && (window.onescript = {
  Create: gt.Create
});
const os = {
  Create: gt.Create
};
export {
  os as default
};
